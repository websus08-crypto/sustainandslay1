"use client"

import type React from "react"

import { Navigation } from "./Navigation"
import { Footer } from "./Footer"

export function ClientLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navigation />
      {children}
      <Footer />
    </>
  )
}
