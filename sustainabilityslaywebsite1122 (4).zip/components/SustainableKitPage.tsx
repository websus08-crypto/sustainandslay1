"use client"

import { Button } from "./ui/button"
import { ArrowLeft, Leaf, Recycle, X } from "lucide-react"
import { useState } from "react"
import Image from "next/image"

interface SustainableKitPageProps {
  onBack?: () => void
  onVendorsClick?: () => void
}

const sustainableItems = [
  {
    name: "Reusable Mug",
    description: "Eco-friendly ceramic mug with charming heart pattern for your daily beverages",
    image: "/sustainable-mug.png",
  },
  {
    name: "Bamboo Toothbrush",
    description: "Biodegradable bamboo toothbrushes with soft bristles for sustainable oral care",
    image: "/sustainable-toothbrush.png",
  },
  {
    name: "Sustainable Cutlery Set",
    description: "Elegant reusable cutlery set with natural wooden handles for on-the-go dining",
    image: "/sustainable-cutlery.png",
  },
  {
    name: "Eco-Friendly Bag",
    description: "Durable canvas backpack made from sustainable materials for everyday use",
    image: "/sustainable-bag.png",
  },
]

export default function SustainableKitPage({ onBack, onVendorsClick }: SustainableKitPageProps) {
  const [selectedItem, setSelectedItem] = useState<(typeof sustainableItems)[0] | null>(null)

  return (
    <div className="min-h-screen bg-[#faf7f2]">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#f4ede4] to-[#dccdb2] border-b border-[#dccdb2]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center gap-4 mb-6">
            <Button variant="ghost" size="sm" onClick={onBack} className="hover:bg-white/50 text-[#3a7a5e]">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          </div>

          <div className="text-center max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-2 mb-4">
              
              <h1 className="text-4xl md:text-5xl font-display text-[#3a7a5e]">Sustainable Kit</h1>
              <Recycle className="h-8 w-8 text-[#3a7a5e]" />
            </div>
            <p className="text-xl text-[#6b4f3d] mb-8 leading-relaxed">
              Your complete guide to eco-friendly essentials that make sustainable living simple and impactful.
            </p>
          </div>
        </div>
      </div>

      <div className="py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-display text-[#3a7a5e] mb-4">Essential Sustainable Swaps</h2>
            <p className="text-lg text-[#6b4f3d] max-w-2xl mx-auto">
              Click on any item to learn more about sustainable alternatives
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 max-w-6xl mx-auto">
            {sustainableItems.map((item, index) => (
              <button
                key={index}
                onClick={() => setSelectedItem(item)}
                className="w-full aspect-square bg-[#FAF7F2] rounded-[20px] p-6 hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer border border-[#dccdb2]/30 group shadow-xl hover:shadow-[0_25px_50px_rgba(0,0,0,0.25)]"
              >
                <div className="flex items-center justify-center h-full group-hover:scale-110 transition-transform duration-300">
                  <Image
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    width={240}
                    height={240}
                    className="object-contain max-w-[85%] max-h-[85%]"
                  />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {selectedItem && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 relative">
            <button
              onClick={() => setSelectedItem(null)}
              className="absolute top-4 right-4 p-2 hover:bg-[#f4ede4] rounded-full transition-colors"
            >
              <X className="h-5 w-5 text-[#6b4f3d]" />
            </button>

            <div className="text-center mb-6">
              <div className="flex items-center justify-center mb-4 p-4 bg-[#f4ede4] rounded-xl">
                <Image
                  src={selectedItem.image || "/placeholder.svg"}
                  alt={selectedItem.name}
                  width={80}
                  height={80}
                  className="object-contain"
                />
              </div>
              <h3 className="text-2xl font-display text-[#3a7a5e] mb-2">{selectedItem.name}</h3>
              {selectedItem.name === "Reusable Mug" ? (
                <p className="text-[#6b4f3d] leading-relaxed mb-6">Eco-friendly mug for your daily beverages</p>
              ) : (
                <p className="text-[#6b4f3d] leading-relaxed mb-6">{selectedItem.description}</p>
              )}
            </div>

            <div className="bg-[#f4ede4] rounded-xl p-4 text-center">
              <p className="text-[#3a7a5e] font-semibold text-lg">List of sustainable vendors: Coming Soon!</p>
              <p className="text-[#6b4f3d] text-sm mt-1">We're curating the best sustainable suppliers for you</p>
            </div>
          </div>
        </div>
      )}

      {/* Call to Action */}
      <div className="py-16 bg-[#f4ede4]">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-display text-[#3a7a5e] mb-4">Ready to Start Your Sustainable Journey?</h2>
          <p className="text-lg text-[#6b4f3d] mb-8">
            Explore our curated collection of eco-friendly products and sustainable vendors
          </p>
          <Button
            disabled
            className="bg-[#3a7a5e]/50 text-white text-lg px-8 py-4 rounded-xl cursor-not-allowed opacity-75"
          >
            Vendors Coming Soon
          </Button>
        </div>
      </div>
    </div>
  )
}
