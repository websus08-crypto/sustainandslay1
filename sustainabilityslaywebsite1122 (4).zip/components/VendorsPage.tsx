"use client"

import { motion } from "framer-motion"
import { Button } from "./ui/button"
import { ArrowLeft } from "lucide-react"

interface VendorsPageProps {
  onBack?: () => void
}

export default function VendorsPage({ onBack }: VendorsPageProps) {
  return (
    <div className="min-h-screen bg-[#F5F1E8] text-[#2D3A2B] px-4 sm:px-6 lg:px-8 py-20 flex flex-col items-center justify-center">
      <div className="absolute top-8 left-8">
        <Button variant="ghost" onClick={onBack} className="text-[#2D3A2B] hover:text-[#6B8E5A] hover:bg-[#6B8E5A]/10">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Button>
      </div>

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <h1 className="text-6xl md:text-7xl lg:text-8xl font-bold mb-8 text-[#6B8E5A] leading-tight">Coming soon!</h1>
        <p className="text-xl md:text-2xl text-[#2D3A2B] max-w-2xl mx-auto leading-relaxed">
          We're building a curated list of sustainable and eco-friendly vendors for your events.
        </p>
      </motion.section>
    </div>
  )
}
