"use client"

import { useState, useEffect, useMemo, useCallback, memo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"
import { Checkbox } from "./ui/checkbox"
import { Slider } from "./ui/slider"
import { Calendar } from "./ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select"
import { EventCompleteStep } from "./event-flow/EventCompleteStep"
import { Clock } from "lucide-react"
import {
  ArrowLeft,
  ArrowRight,
  Plus,
  Minus,
  CalendarIcon,
  Eye,
  EyeOff,
  ShoppingCart,
  User,
  Mail,
  Lock,
  Check,
  Leaf,
  Heart,
} from "lucide-react"
import { cn } from "../lib/utils"
import Image from "next/image"

// Simple date formatter utility
const formatDate = (date: Date | undefined) => {
  if (!date || !(date instanceof Date) || isNaN(date.getTime())) {
    return "Pick a date"
  }
  return date.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

const INDIAN_STATES = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu",
  "Delhi",
  "Jammu and Kashmir",
  "Ladakh",
  "Lakshadweep",
  "Puducherry",
]

export interface EventData {
  // Event Type
  eventType: string

  // Basics
  city: string
  date: Date | undefined
  guests: number
  budget: number[]
  priorities: string[]

  // Services
  selectedServices: Array<{
    id: string
    category: string
    name: string
    description: string
    price: string
  }>

  // User
  user?: {
    name: string
    email: string
    password: string
  }
}

interface EventPlanningFlowProps {
  onComplete?: () => void
  onBack?: () => void
  eventType?: string
}

const EVENT_TYPES = [
  {
    id: "birthday",
    name: "Birthday Party",
    image: "/birthday-party-sustainable.jpg",
    description: "Celebrate sustainably with eco-friendly decorations and locally-sourced treats",
  },
  {
    id: "corporate",
    name: "Corporate Event",
    image: "/corporate-event-sustainable.jpg",
    description: "Professional gatherings with zero-waste catering and carbon-neutral practices",
  },
  {
    id: "wedding",
    name: "Wedding",
    image: "/indian-wedding-sustainable-new.jpg",
    description: "Your special day with ethical vendors and environmentally conscious choices",
  },
  {
    id: "custom",
    name: "Create Your Own Event",
    image:
      "https://images.unsplash.com/photo-1712903276173-c6e36c3b8a97?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b20lMjBldmVudCUyMHBsYW5uaW5nJTIwY3JlYXRpdmUlMjBzZXR1cHxlbnwxfHx8fDE3NTY5MjQwMDN8MA&ixlib=rb-4.1.0&q=80&w=400&utm_source=figma&utm_medium=referral",
    description: "Unique celebrations tailored to your vision and values",
  },
]

const SERVICE_CATEGORIES = [
  {
    id: "decor",
    name: "Decor",
    description: "Sustainable centerpieces, reusable decorations, and biodegradable balloons",
    services: [
      { id: "eco-centerpieces", name: "Eco Centerpieces", price: "₹10,000-25,000" },
      { id: "reusable-decor", name: "Reusable Decorations", price: "₹16,000-40,000" },
      { id: "living-walls", name: "Living Plant Walls", price: "₹32,000-65,000" },
    ],
  },
  {
    id: "catering",
    name: "Catering",
    description: "Local organic food, zero-waste packaging, and plant-forward menus",
    services: [
      { id: "organic-catering", name: "Organic Local Catering", price: "₹2,000-3,500/person" },
      { id: "zero-waste-service", name: "Zero-Waste Service", price: "₹1,200-2,000/person" },
      { id: "plant-based-menu", name: "Plant-Based Menu", price: "₹1,600-2,800/person" },
    ],
  },
  {
    id: "gifting",
    name: "Gifting",
    description: "Ethical favors, plantable gifts, and experience-based presents",
    services: [
      { id: "plantable-favors", name: "Plantable Seed Favors", price: "₹250-650/guest" },
      { id: "ethical-gifts", name: "Ethical Gift Curations", price: "₹1,200-4,000/guest" },
      { id: "experience-vouchers", name: "Experience Vouchers", price: "₹2,000-8,000/guest" },
    ],
  },
  {
    id: "outfits",
    name: "Outfits",
    description: "Sustainable fashion, rental options, and ethical accessories",
    services: [
      { id: "sustainable-styling", name: "Sustainable Styling", price: "₹12,000-32,000" },
      { id: "outfit-rental", name: "Designer Outfit Rental", price: "₹8,000-25,000" },
      { id: "ethical-accessories", name: "Ethical Accessories", price: "₹4,000-16,000" },
    ],
  },
  {
    id: "entertainment",
    name: "Entertainment",
    description: "Local musicians, eco-friendly activities, and nature-based experiences",
    services: [
      { id: "local-musicians", name: "Local Musicians", price: "₹25,000-65,000" },
      { id: "nature-activities", name: "Nature-Based Activities", price: "₹16,000-40,000" },
      { id: "sustainable-photo", name: "Sustainable Photography", price: "₹32,000-95,000" },
    ],
  },
  {
    id: "logistics",
    name: "Logistics",
    description: "Carbon-neutral transport, waste management, and venue coordination",
    services: [
      { id: "transport-coordination", name: "Carbon-Neutral Transport", price: "₹8,000-25,000" },
      { id: "waste-management", name: "Zero-Waste Coordination", price: "₹12,000-32,000" },
      { id: "venue-setup", name: "Sustainable Venue Setup", price: "₹16,000-48,000" },
    ],
  },
]

const SUSTAINABILITY_PRIORITIES = [
  "Waste reduction",
  "Local sourcing",
  "Carbon-neutral travel",
  "Plastic-free materials",
  "Renewable energy",
  "Water conservation",
  "Ethical labor practices",
  "Biodegradable products",
]

const MOCK_VENDORS = [
  {
    id: "1",
    name: "Green Leaf Catering",
    category: "Catering",
    description: "Farm-to-table organic catering with zero-waste practices",
    sustainability: "Locally sourced ingredients, compostable packaging, carbon-neutral delivery",
    rating: 4.9,
    location: "San Francisco Bay Area",
  },
  {
    id: "2",
    name: "Eco Bloom Designs",
    category: "Decor",
    description: "Sustainable floral arrangements and reusable decorations",
    sustainability: "Seasonal flowers, biodegradable materials, rental options available",
    rating: 4.8,
    location: "San Francisco Bay Area",
  },
  {
    id: "3",
    name: "Conscious Captures",
    category: "Entertainment",
    description: "Photography studio committed to sustainable practices",
    sustainability: "Digital-first delivery, eco-friendly printing, carbon offset programs",
    rating: 4.7,
    location: "San Francisco Bay Area",
  },
]

type Step = "hero" | "categories" | "details" | "services" | "auth" | "vendors" | "consultation" | "complete"

export const EventPlanningFlow = memo(function EventPlanningFlow({
  onComplete,
  onBack,
  eventType,
}: EventPlanningFlowProps) {
  const [currentStep, setCurrentStep] = useState<Step>("hero")
  const [eventData, setEventData] = useState<EventData>({
    eventType: eventType || "",
    city: "",
    date: undefined,
    guests: 50,
    budget: [0],
    priorities: [],
    selectedServices: [],
    user: undefined,
  })

  const [isLoginMode, setIsLoginMode] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [authForm, setAuthForm] = useState({
    name: "",
    email: "",
    password: "",
  })

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [currentStep])

  // Auto-save to localStorage
  useEffect(() => {
    const savedData = localStorage.getItem("eventPlanningDraft")
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData)
        setEventData((prev) => ({ ...prev, ...parsed }))
      } catch (e) {
        console.error("Failed to parse saved event data")
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("eventPlanningDraft", JSON.stringify(eventData))
  }, [eventData])

  const updateEventData = useCallback((updates: Partial<EventData>) => {
    setEventData((prev) => ({ ...prev, ...updates }))
  }, [])

  const addService = useCallback((service: any, category: string) => {
    const newService = {
      id: service.id,
      category,
      name: service.name,
      description: SERVICE_CATEGORIES.find((cat) => cat.id === category)?.description || "",
      price: service.price,
    }

    setEventData((prev) => ({
      ...prev,
      selectedServices: [...prev.selectedServices, newService],
    }))
  }, [])

  const removeService = useCallback((serviceId: string) => {
    setEventData((prev) => ({
      ...prev,
      selectedServices: prev.selectedServices.filter((s) => s.id !== serviceId),
    }))
  }, [])

  const handleAuth = useCallback(() => {
    setEventData((prev) => ({
      ...prev,
      user: {
        name: authForm.name || "Guest User",
        email: authForm.email || "guest@example.com",
        password: authForm.password || "password",
      },
    }))

    setCurrentStep("vendors")
  }, [authForm])

  const renderHero = useMemo(
    () => (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="min-h-screen bg-background flex items-center justify-center relative"
      >
        <div className="absolute top-8 left-8">
          <Button variant="ghost" onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </div>

        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-h1 font-display mb-6"
          >
            Plan an event that's stylish, sustainable, and guilt-free.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto"
          >
            Choose your event type and explore curated services that minimize waste, water, and carbon impact.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <Button onClick={() => setCurrentStep("categories")} size="lg" className="px-8 py-4">
              Start Planning
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </div>
      </motion.div>
    ),
    [onBack],
  )

  const renderCategories = useMemo(
    () => (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="min-h-screen bg-background py-16"
      >
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-h2 font-display mb-4">Choose Your Event Type</h2>
            <p className="text-lg text-muted-foreground">Select the type of event you're planning</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {EVENT_TYPES.map((type, index) => (
              <motion.div
                key={type.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="group cursor-pointer"
                onClick={() => {
                  setEventData((prev) => ({ ...prev, eventType: type.name }))
                  setCurrentStep("details")
                }}
              >
                <Card className="h-full overflow-hidden border-0 shadow-lg group-hover:shadow-xl transition-all duration-300">
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={type.image || "/placeholder.svg"}
                      alt={type.name}
                      width={400}
                      height={300}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    <div className="absolute bottom-6 left-6 text-white">
                      <h3 className="text-2xl font-bold mb-2 text-background">{type.name}</h3>
                      <p className="text-sm opacity-90">{type.description}</p>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <p className="text-muted-foreground mb-4">{type.description}</p>
                    <Button className="w-full group-hover:bg-primary/90 transition-colors">Select Event Type</Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="text-center">
            <Button
              variant="ghost"
              onClick={() => setCurrentStep("hero")}
              className="text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Start
            </Button>
          </div>
        </div>
      </motion.div>
    ),
    [],
  )

  const renderDetails = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen bg-background py-16"
    >
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-h2 font-display mb-4">Event Details</h2>
          <p className="text-lg text-muted-foreground">Tell us about your {eventData.eventType.toLowerCase()}</p>
        </div>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-8 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Event Type</Label>
                <Input value={eventData.eventType} disabled className="bg-muted" />
              </div>

              <div className="space-y-2">
                <Label>Location (State/City)</Label>
                <Select value={eventData.city} onValueChange={(value) => updateEventData({ city: value })}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select state or enter city" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDIAN_STATES.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Event Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !eventData.date && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {formatDate(eventData.date)}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={eventData.date}
                      onSelect={(date) => updateEventData({ date })}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Number of Guests</Label>
                <Input
                  type="number"
                  value={eventData.guests}
                  onChange={(e) => updateEventData({ guests: Number.parseInt(e.target.value) || 0 })}
                  min="1"
                />
              </div>
            </div>

            <div className="space-y-4">
              <Label>Budget Range: ₹{eventData.budget[0].toLocaleString()}</Label>
              <Slider
                value={eventData.budget}
                onValueChange={(value) => updateEventData({ budget: value })}
                max={4000000}
                min={0}
                step={10000}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>₹0</span>
                <span>₹40,00,000+</span>
              </div>
            </div>

            <div className="space-y-4">
              <Label>Sustainability Priorities</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {SUSTAINABILITY_PRIORITIES.map((priority) => (
                  <div key={priority} className="flex items-center space-x-2">
                    <Checkbox
                      id={priority}
                      checked={eventData.priorities.includes(priority)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          updateEventData({
                            priorities: [...eventData.priorities, priority],
                          })
                        } else {
                          updateEventData({
                            priorities: eventData.priorities.filter((p) => p !== priority),
                          })
                        }
                      }}
                    />
                    <Label htmlFor={priority} className="text-sm">
                      {priority}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-between pt-8">
              <Button variant="ghost" onClick={() => setCurrentStep("categories")}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>

              <Button onClick={() => setCurrentStep("services")}>
                Continue to Services
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  )

  const renderServices = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen bg-background py-16"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-h2 font-display mb-4">Select Services</h2>
          <p className="text-lg text-muted-foreground">Choose the services you need for your event</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Services Grid */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {SERVICE_CATEGORIES.map((category, index) => (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Leaf className="h-5 w-5 text-primary" />
                        {category.name}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">{category.description}</p>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {category.services.map((service) => (
                        <div
                          key={service.id}
                          className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div>
                            <div className="font-medium">{service.name}</div>
                            <div className="text-sm text-muted-foreground">{service.price}</div>
                          </div>
                          <Button
                            size="sm"
                            onClick={() => addService(service, category.id)}
                            disabled={eventData.selectedServices.some((s) => s.id === service.id)}
                            variant={
                              eventData.selectedServices.some((s) => s.id === service.id) ? "secondary" : "default"
                            }
                          >
                            {eventData.selectedServices.some((s) => s.id === service.id) ? (
                              <Check className="h-4 w-4" />
                            ) : (
                              <Plus className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Cart Summary */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="lg:col-span-1"
          >
            <Card className="sticky top-8 border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Selected Services ({eventData.selectedServices.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {eventData.selectedServices.length === 0 ? (
                  <p className="text-muted-foreground text-sm">No services selected yet</p>
                ) : (
                  <div className="space-y-3">
                    {eventData.selectedServices.map((service) => (
                      <motion.div
                        key={service.id}
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="flex items-start justify-between p-3 rounded-lg border bg-card"
                      >
                        <div className="flex-1">
                          <div className="font-medium text-sm">{service.name}</div>
                          <div className="text-xs text-muted-foreground capitalize">{service.category}</div>
                          <div className="text-xs text-primary font-medium">{service.price}</div>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeService(service.id)}
                          className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                      </motion.div>
                    ))}
                  </div>
                )}

                <div className="pt-4 border-t">
                  <Button
                    className="w-full"
                    onClick={() => setCurrentStep("auth")}
                    disabled={eventData.selectedServices.length === 0}
                  >
                    Continue to Login
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="text-center mt-12">
          <Button
            variant="ghost"
            onClick={() => setCurrentStep("details")}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Details
          </Button>
        </div>
      </div>
    </motion.div>
  )

  const renderAuth = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen bg-background py-16 flex items-center justify-center"
    >
      <div className="mx-auto max-w-md w-full px-4">
        <Card className="border-0 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-h3 font-display">{isLoginMode ? "Welcome Back" : "Create Account"}</CardTitle>
            <p className="text-muted-foreground">
              {isLoginMode ? "Sign in to see your vendor matches" : "Create an account to discover vendors"}
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {!isLoginMode && (
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter your name"
                    value={authForm.name}
                    onChange={(e) => setAuthForm((prev) => ({ ...prev, name: e.target.value }))}
                    className="pl-10"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={authForm.email}
                  onChange={(e) => setAuthForm((prev) => ({ ...prev, email: e.target.value }))}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={authForm.password}
                  onChange={(e) => setAuthForm((prev) => ({ ...prev, password: e.target.value }))}
                  className="pl-10 pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                </Button>
              </div>
            </div>

            <Button onClick={handleAuth} className="w-full">
              {isLoginMode ? "Sign In" : "Create Account"}
            </Button>

            <div className="text-center">
              <Button variant="link" onClick={() => setIsLoginMode(!isLoginMode)} className="text-muted-foreground">
                {isLoginMode ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
              </Button>
            </div>

            <div className="text-center">
              <Button
                variant="ghost"
                onClick={() => setCurrentStep("services")}
                className="text-muted-foreground hover:text-foreground"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Services
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  )

  const renderVendors = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen bg-background py-16"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-h2 font-display mb-4">Vendors Coming Soon</h2>
          <p className="text-lg text-muted-foreground">
            We're carefully curating the best sustainable vendors for your {eventData.eventType.toLowerCase()}
          </p>
        </div>

        <div className="text-center py-16">
          <div className="w-24 h-24 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-8">
            <Clock className="h-12 w-12 text-primary animate-pulse" />
          </div>

          <h3 className="text-3xl font-display text-primary mb-6">Coming Soon!</h3>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            We're building a curated marketplace of sustainable vendors. You'll be able to browse and connect with
            eco-friendly suppliers soon.
          </p>

          <Button onClick={() => setCurrentStep("consultation")} size="lg" className="px-8 py-4">
            Continue to Consultation
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </motion.div>
  )

  const renderConsultation = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen bg-background py-16 flex items-center justify-center"
    >
      <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="space-y-8"
        >
          <div className="w-24 h-24 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
            <Heart className="h-12 w-12 text-primary" />
          </div>

          <h2 className="text-h2 font-display">Want us to manage everything for you?</h2>

          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Let our sustainability experts handle every detail of your {eventData.eventType.toLowerCase()}. We'll
            coordinate with vendors, ensure zero-waste practices, and create an unforgettable experience.
          </p>

          <div className="space-y-4">
            <Button size="lg" className="px-8 py-4" onClick={() => setCurrentStep("complete")}>
              Book a Consultation
            </Button>

            <div>
              <Button
                variant="ghost"
                onClick={() => setCurrentStep("complete")}
                className="text-muted-foreground hover:text-foreground"
              >
                Continue on your own
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  )

  const renderComplete = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen bg-background py-16"
    >
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <Card className="border-0 shadow-xl">
          <EventCompleteStep
            data={eventData}
            onComplete={() => {
              localStorage.removeItem("eventPlanningDraft")
              onComplete?.()
            }}
            onRefine={() => setCurrentStep("details")}
          />
        </Card>
      </div>
    </motion.div>
  )

  const renderCurrentStep = useCallback(() => {
    switch (currentStep) {
      case "hero":
        return renderHero
      case "categories":
        return renderCategories
      case "details":
        return renderDetails()
      case "services":
        return renderServices()
      case "auth":
        return renderAuth()
      case "vendors":
        return renderVendors()
      case "consultation":
        return renderConsultation()
      case "complete":
        return renderComplete()
      default:
        return renderHero
    }
  }, [currentStep, renderHero, renderCategories, eventData, authForm, isLoginMode, showPassword])

  return (
    <div className="min-h-screen">
      <AnimatePresence mode="wait">{renderCurrentStep()}</AnimatePresence>
    </div>
  )
})
