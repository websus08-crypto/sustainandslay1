"use client"
import { Linkedin } from "lucide-react"

type AboutPageProps = {}

export default function AboutPage({}: AboutPageProps) {
  return (
    <div className="py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-h1 font-display font-semibold mb-8 text-primary">About Sustain & Slay</h1>
          <div className="max-w-4xl mx-auto">
            <p className="text-lg text-foreground leading-relaxed mb-6">
              We're the kind of people who notice the food waste at weddings more than the food itself.
            </p>
            <p className="text-lg text-foreground leading-relaxed mb-6">
              A bunch of curious, climate-conscious dreamers (that's us!) came together and asked: What if events could
              be fun and planet-positive at the same time?
            </p>
            <p className="text-lg text-foreground leading-relaxed mb-6">
              We're a bunch of celebration-lovers and climate worriers who decided to do something about the chaos and
              the carbon. We love a good mehendi playlist, OTT decor, and those late-night dance parties but not at the
              cost of overflowing landfills or single-use anything.
            </p>
            <p className="text-lg text-foreground leading-relaxed mb-6">
              Believing in the power of action and the art of rewriting narratives, we launched this platform to
              reimagine event planning a one-stop destination for discovering and hosting sustainable weddings, parties,
              and joyful gatherings across India. From eco-friendly vendors to plastic-free party tips, we're making it
              easy (and sexy) to party with a conscience.
            </p>
            <p className="text-lg text-foreground leading-relaxed mb-6">
              For us, thoughtful celebrations go beyond perfection; they are about creativity, genuine connections, and
              ensuring every gathering is a little gentler on the planet. After all, the best celebrations aren't just
              the ones that feel good but the ones that do good long after the music fades.
            </p>
            <p className="text-lg text-primary font-medium leading-relaxed mb-8">
              If you're the kind of person who wants your celebration to reflect your values (without giving up on the
              gulab jamuns or good times), welcome. We're here for the mindful misfits, the climate romantics, and the
              people who believe the Earth deserves an invite too.
            </p>
            <p className="text-xl font-semibold text-accent">
              Let's make sustainability easy, simple, fun and memorable!
            </p>
          </div>
        </div>

        {/* Team Section */}
        <div className="mb-16">
          <h2 className="text-h2 font-display font-semibold text-center mb-12 text-primary">Meet Our Team</h2>

          <div className="grid grid-cols-1 gap-16 max-w-2xl mx-auto">
            {/* Alisha */}
            <div className="text-center">
              <div className="mb-6">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Alisha.jpg-cVUfdtYJ5OvxGsell1mageokHjPYVq.jpeg"
                  alt="Alisha"
                  className="w-64 h-64 rounded-full mx-auto object-cover shadow-lg"
                />
              </div>
              <div className="flex items-center justify-center gap-3 mb-4">
                <h3 className="text-h3 font-display font-semibold text-primary">Alisha</h3>
                <a
                  href="https://www.linkedin.com/in/alisha-butala-85368580/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:text-primary transition-colors"
                  aria-label="Alisha's LinkedIn"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
              <p className="text-foreground leading-relaxed">
                {
                  "I believe every gathering is enriched by the stories people carry with them, and I’ve always been curious about what drives and inspires others. A policy analyst by profession and a climate optimist at heart, I hold a Master’s in Public Policy from King’s College London. My journey has taken me from working with the education ministries of Delhi and Maharashtra to digitising education systems and leading Desh Ke Mentor, India’s largest mentoring initiative.\nAt the core, I see myself as a “dishabituation entrepreneur”someone committed to breaking patterns, questioning defaults, and creating fresh ways of doing things. Change, for me, isn’t about grand gestures; it’s about small, thoughtful actions that let me rest peacefully at night knowing I moved the needle, however slightly."
                }
              </p>
            </div>

            {/* Mehar */}
            <div className="text-center">
              <div className="mb-6">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mehar.jpg-QWrAoj57e0AzK7oY0dWNw192nO7QxV.jpeg"
                  alt="Mehar"
                  className="w-64 h-64 rounded-full mx-auto object-cover shadow-lg"
                />
              </div>
              <div className="flex items-center justify-center gap-3 mb-4">
                <h3 className="text-h3 font-display font-semibold text-primary">Mehar</h3>
                <a
                  href="https://www.linkedin.com/in/meharpandya/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:text-primary transition-colors"
                  aria-label="Mehar's LinkedIn"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
              <p className="text-foreground leading-relaxed">
                Over the past five years, I've explored the many layers of climate action - from the technical and
                institutional to the cultural and ecological. My work spans public transport, urban planning, emissions
                trading, and waste management, as well as wetlands, ecosystem conservation, and indigenous practices.
                Having studied Political Science from the University of Delhi and Public Policy from King's College
                London, I approach climate issues through a systemic lens. I believe that long-term change doesn't
                emerge from a single sector or solution, but through the careful interlinking of diverse voices and
                visions.
              </p>
            </div>

            {/* Yukta */}
            <div className="text-center">
              <div className="mb-6">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/yukta-kPCc90MhdY8hovgMCVNUC1Y5Z0h93L.jpeg"
                  alt="Yukta"
                  className="w-64 h-64 rounded-full mx-auto object-cover shadow-lg"
                />
              </div>
              <div className="flex items-center justify-center gap-3 mb-4">
                <h3 className="text-h3 font-display font-semibold text-primary">Yukta</h3>
                <a
                  href="https://www.linkedin.com/in/yukta-bansal-643502290"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-accent hover:text-primary transition-colors"
                  aria-label="Yukta's LinkedIn"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
              <p className="text-foreground leading-relaxed">
                I'm Yukta, a University of Delhi grad who loves exploring the sweet spot where tech, climate, and
                community meet. My journey has taken me from researching ethical AI to working on grassroots climate
                action and health initiatives, all tied together by one belief: small choices can spark big change. I
                believe sustainability isn't about perfection. It's about creativity, balance, and joy in the process.
                Conscious living should feel empowering, not exhausting.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
