"use client"

import { useState } from "react"
import { Button } from "../../components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card"
import { Badge } from "../../components/ui/badge"
import { Checkbox } from "../../components/ui/checkbox"
import { Separator } from "../../components/ui/separator"
import { ArrowLeft, ArrowRight, Calendar, MapPin, Users, IndianRupee, Target, ShoppingCart, Check } from "lucide-react"
import type { EventData } from "../EventPlanningFlow"

interface EventReviewStepProps {
  data: EventData
  onNext: () => void
  onBack: () => void
}

export function EventReviewStep({ data, onNext, onBack }: EventReviewStepProps) {
  const [consentGiven, setConsentGiven] = useState(false)

  const handleSubmit = () => {
    if (!consentGiven) {
      alert("Please agree to be contacted with vendor options")
      return
    }
    onNext()
  }

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "Not specified"
    const date = new Date(dateStr)
    return date.toLocaleDateString("en-IN", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const getTotalServiceCount = () => {
    return data.services.reduce((total, service) => total + service.subServices.length, 0)
  }

  return (
    <div>
      <CardHeader>
        <CardTitle className="flex items-center text-2xl">
          <Check className="h-6 w-6 mr-3 text-primary" />
          Review Your Event
        </CardTitle>
        <p className="text-muted-foreground">
          Please review your event details before we find the perfect vendors for you
        </p>
      </CardHeader>

      <CardContent className="space-y-8">
        {/* Event Basics Summary */}
        <Card className="border-0 bg-muted/30">
          <CardHeader>
            <CardTitle className="text-lg">Event Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="font-medium">{data.city || "Not specified"}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Date</p>
                  <p className="font-medium">{formatDate(data.date)}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Users className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Guests</p>
                  <p className="font-medium">{data.guests} people</p>
                </div>
              </div>

              {data.budget && (
                <div className="flex items-center space-x-3">
                  <IndianRupee className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Budget</p>
                    <p className="font-medium">{data.budget}</p>
                  </div>
                </div>
              )}
            </div>

            {data.venueType && (
              <div>
                <p className="text-sm text-muted-foreground mb-1">Venue Type</p>
                <Badge variant="secondary">{data.venueType}</Badge>
              </div>
            )}

            {data.style && (
              <div>
                <p className="text-sm text-muted-foreground mb-1">Event Style</p>
                <Badge variant="secondary">{data.style}</Badge>
              </div>
            )}

            {data.goals.length > 0 && (
              <div>
                <p className="text-sm text-muted-foreground mb-2">Sustainability Goals</p>
                <div className="flex flex-wrap gap-2">
                  {data.goals.map((goal) => (
                    <Badge key={goal} className="bg-primary/10 text-primary border-primary/20">
                      <Target className="h-3 w-3 mr-1" />
                      {goal}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {data.notes && (
              <div>
                <p className="text-sm text-muted-foreground mb-1">Additional Notes</p>
                <p className="text-sm bg-background rounded-md p-3">{data.notes}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Services Summary */}
        <Card className="border-0 bg-muted/30">
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <ShoppingCart className="h-5 w-5 mr-2" />
              Selected Services ({getTotalServiceCount()} items)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.services.length > 0 ? (
              <div className="space-y-4">
                {data.services.map((service, index) => (
                  <div key={service.category}>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{service.category}</h4>
                      <Badge variant="outline">{service.subServices.length} selected</Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 ml-4">
                      {service.subServices.map((subService) => (
                        <div key={subService} className="text-sm text-muted-foreground flex items-center">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></div>
                          {subService}
                        </div>
                      ))}
                    </div>
                    {index < data.services.length - 1 && <Separator className="mt-4" />}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No services selected</p>
            )}
          </CardContent>
        </Card>

        {/* Consent */}
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-3">
              <Checkbox
                id="consent"
                checked={consentGiven}
                onCheckedChange={(checked) => setConsentGiven(checked as boolean)}
                className="mt-1"
              />
              <div className="space-y-2">
                <label htmlFor="consent" className="text-sm font-medium leading-relaxed cursor-pointer">
                  I agree to be contacted with a curated vendor list for this event
                </label>
                <p className="text-xs text-muted-foreground">
                  We'll only use your details to share vendor options for your event. We respect your privacy and won't
                  share your information with third parties.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Services
          </Button>
          <Button onClick={handleSubmit} size="lg" disabled={!consentGiven} className="px-8">
            Continue to Login
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </div>
  )
}
