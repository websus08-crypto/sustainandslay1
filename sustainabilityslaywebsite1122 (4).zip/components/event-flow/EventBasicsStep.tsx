"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Label } from "../ui/label"
import { Textarea } from "../ui/textarea"
import { Slider } from "../ui/slider"
import { Badge } from "../ui/badge"
import { CardContent, CardHeader, CardTitle } from "../ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select"
import { Calendar, MapPin, Users, DollarSign, Palette, Target, ArrowRight } from "lucide-react"
import type { EventData } from "../EventPlanningFlow"

interface EventBasicsStepProps {
  data: EventData
  eventType?: string
  onUpdate: (updates: Partial<EventData>) => void
  onNext: () => void
}

const venueTypes = [
  "Indoor",
  "Outdoor",
  "Hybrid (Indoor + Outdoor)",
  "Home/Private Residence",
  "Restaurant/Venue",
  "Community Space",
  "Other",
]

const eventStyles = [
  "Minimal & Clean",
  "Luxe & Elegant",
  "Rustic & Natural",
  "Traditional & Cultural",
  "Modern & Contemporary",
  "Bohemian & Artistic",
  "Industrial & Urban",
]

const sustainabilityGoals = [
  "Waste-lite decor",
  "Plastic-free",
  "Plant-forward menu",
  "Local sourcing",
  "Carbon-aware travel",
  "Reusable materials",
  "Digital-first invites",
  "Compostable packaging",
]

const budgetRanges = [
  "Under ₹25,000",
  "₹25,000 - ₹75,000",
  "₹75,000 - ₹1,50,000",
  "₹1,50,000 - ₹3,00,000",
  "₹3,00,000 - ₹5,00,000",
  "Above ₹5,00,000",
]

export function EventBasicsStep({ data, eventType, onUpdate, onNext }: EventBasicsStepProps) {
  const [guests, setGuests] = useState([data.guests || 50])
  const [selectedGoals, setSelectedGoals] = useState<string[]>(data.goals || [])

  const toggleGoal = (goal: string) => {
    const newGoals = selectedGoals.includes(goal) ? selectedGoals.filter((g) => g !== goal) : [...selectedGoals, goal]
    setSelectedGoals(newGoals)
    onUpdate({ goals: newGoals })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validation
    if (!data.city || !data.date || !data.venueType) {
      alert("Please fill in all required fields")
      return
    }

    onNext()
  }

  const isValid = data.city && data.date && data.venueType

  return (
    <form onSubmit={handleSubmit}>
      <CardHeader>
        <CardTitle className="flex items-center text-2xl">
          <Calendar className="h-6 w-6 mr-3 text-primary" />
          Event Basics
          {eventType && (
            <Badge variant="secondary" className="ml-3 text-sm">
              {eventType}
            </Badge>
          )}
        </CardTitle>
        <p className="text-muted-foreground">Tell us about your event vision and sustainability goals</p>
      </CardHeader>

      <CardContent className="space-y-8">
        {/* Location & Venue */}
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="city" className="flex items-center mb-2">
              <MapPin className="h-4 w-4 mr-2" />
              City/Location *
            </Label>
            <Input
              id="city"
              placeholder="e.g., Mumbai, Delhi, Bangalore"
              value={data.city}
              onChange={(e) => onUpdate({ city: e.target.value })}
              required
            />
          </div>

          <div>
            <Label className="mb-2 block">Venue Type *</Label>
            <Select value={data.venueType} onValueChange={(value) => onUpdate({ venueType: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select venue type" />
              </SelectTrigger>
              <SelectContent>
                {venueTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Date & Guests */}
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="date" className="mb-2 block">
              Event Date *
            </Label>
            <Input
              id="date"
              type="date"
              value={data.date}
              onChange={(e) => onUpdate({ date: e.target.value })}
              required
            />
          </div>

          <div>
            <Label className="flex items-center mb-2">
              <Users className="h-4 w-4 mr-2" />
              Number of Guests: {guests[0]}
            </Label>
            <Slider
              value={guests}
              onValueChange={(value) => {
                setGuests(value)
                onUpdate({ guests: value[0] })
              }}
              max={500}
              min={10}
              step={5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>10</span>
              <span>500+</span>
            </div>
          </div>
        </div>

        {/* Budget & Style */}
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Label className="flex items-center mb-2">
              <DollarSign className="h-4 w-4 mr-2" />
              Budget Range
            </Label>
            <Select value={data.budget} onValueChange={(value) => onUpdate({ budget: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select budget range" />
              </SelectTrigger>
              <SelectContent>
                {budgetRanges.map((range) => (
                  <SelectItem key={range} value={range}>
                    {range}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="flex items-center mb-2">
              <Palette className="h-4 w-4 mr-2" />
              Event Style
            </Label>
            <Select value={data.style} onValueChange={(value) => onUpdate({ style: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select style preference" />
              </SelectTrigger>
              <SelectContent>
                {eventStyles.map((style) => (
                  <SelectItem key={style} value={style}>
                    {style}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Sustainability Goals */}
        <div>
          <Label className="flex items-center mb-4">
            <Target className="h-4 w-4 mr-2" />
            Sustainability Goals
          </Label>
          <p className="text-sm text-muted-foreground mb-4">
            Select the areas where you'd like to focus on sustainability (choose any that matter to you)
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {sustainabilityGoals.map((goal) => (
              <Badge
                key={goal}
                variant={selectedGoals.includes(goal) ? "default" : "outline"}
                className={`cursor-pointer text-center py-2 px-3 text-xs transition-colors ${
                  selectedGoals.includes(goal)
                    ? "bg-primary text-primary-foreground hover:bg-primary/90"
                    : "hover:bg-accent"
                }`}
                onClick={() => toggleGoal(goal)}
              >
                {goal}
              </Badge>
            ))}
          </div>
        </div>

        {/* Additional Notes */}
        <div>
          <Label htmlFor="notes" className="mb-2 block">
            Additional Notes
          </Label>
          <Textarea
            id="notes"
            placeholder="Any specific requirements, themes, or concerns you'd like us to know about..."
            value={data.notes}
            onChange={(e) => onUpdate({ notes: e.target.value })}
            rows={3}
          />
        </div>

        {/* Submit */}
        <div className="flex justify-end pt-6">
          <Button type="submit" size="lg" disabled={!isValid} className="px-8">
            Continue to Services
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </form>
  )
}
