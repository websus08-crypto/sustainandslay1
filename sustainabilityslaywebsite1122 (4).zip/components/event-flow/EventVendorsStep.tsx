"use client"

import { useState, useEffect } from "react"
import { Button } from "../../components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card"
import { Badge } from "../../components/ui/badge"
import { Skeleton } from "../../components/ui/skeleton"
import { ArrowLeft, ArrowRight, MapPin, Star, Leaf, Users, Mail, CheckCircle, ExternalLink } from "lucide-react"
import type { EventData } from "../EventPlanningFlow"

interface EventVendorsStepProps {
  data: EventData
  onNext: () => void
  onBack: () => void
}

interface Vendor {
  id: string
  name: string
  category: string
  rating: number
  location: string
  distance: string
  specialties: string[]
  sustainabilityBadges: string[]
  description: string
  priceRange: string
  responseTime: string
  verified: boolean
}

// Mock vendor data based on selected services
const generateVendors = (services: Array<{ category: string; subServices: string[] }>): Vendor[] => {
  const mockVendors: Record<string, Vendor[]> = {
    Decor: [
      {
        id: "decor-1",
        name: "Green Spaces Design",
        category: "Decor",
        rating: 4.8,
        location: "Mumbai",
        distance: "5 km",
        specialties: ["Rental backdrops", "Plant arrangements", "Eco lighting"],
        sustainabilityBadges: ["Zero-waste", "Rental-first", "Local sourcing"],
        description: "Specializing in sustainable event decor with 100% rental and reusable materials.",
        priceRange: "₹25,000 - ₹75,000",
        responseTime: "Responds within 2 hours",
        verified: true,
      },
      {
        id: "decor-2",
        name: "Upcycle Studio",
        category: "Decor",
        rating: 4.6,
        location: "Mumbai",
        distance: "8 km",
        specialties: ["Upcycled centerpieces", "Vintage rentals", "Fabric draping"],
        sustainabilityBadges: ["Upcycled materials", "Carbon neutral"],
        description: "Creative studio transforming waste into beautiful event decor.",
        priceRange: "₹15,000 - ₹50,000",
        responseTime: "Responds within 4 hours",
        verified: true,
      },
    ],
    Catering: [
      {
        id: "catering-1",
        name: "Farm to Feast",
        category: "Catering",
        rating: 4.9,
        location: "Mumbai",
        distance: "3 km",
        specialties: ["Plant-forward menus", "Local ingredients", "Zero-waste service"],
        sustainabilityBadges: ["Organic certified", "Plastic-free", "Local sourcing"],
        description: "Award-winning caterer focused on seasonal, local, and plant-based cuisine.",
        priceRange: "₹800 - ₹1,500 per person",
        responseTime: "Responds within 1 hour",
        verified: true,
      },
    ],
    Photography: [
      {
        id: "photo-1",
        name: "Digital Moments Studio",
        category: "Photography",
        rating: 4.7,
        location: "Mumbai",
        distance: "6 km",
        specialties: ["Digital-only packages", "Drone photography", "Cloud delivery"],
        sustainabilityBadges: ["Carbon offset", "Digital-first"],
        description: "Modern photography studio with completely digital workflows and eco-conscious practices.",
        priceRange: "₹40,000 - ₹80,000",
        responseTime: "Responds within 3 hours",
        verified: true,
      },
    ],
  }

  const vendors: Vendor[] = []
  services.forEach((service) => {
    if (mockVendors[service.category]) {
      vendors.push(...mockVendors[service.category])
    }
  })

  return vendors
}

export function EventVendorsStep({ data, onNext, onBack }: EventVendorsStepProps) {
  const [vendors, setVendors] = useState<Vendor[]>([])
  const [loading, setLoading] = useState(true)
  const [emailSent, setEmailSent] = useState(false)

  useEffect(() => {
    // Simulate API call to fetch vendors
    setTimeout(() => {
      const generatedVendors = generateVendors(data.selectedServices || [])
      setVendors(generatedVendors)
      setLoading(false)
    }, 2000)
  }, [data.selectedServices])

  const handleEmailVendors = () => {
    setEmailSent(true)
    // In real app, this would trigger an email API call
  }

  const getTotalVendorCount = () => {
    return vendors.length
  }

  if (loading) {
    return (
      <div>
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Users className="h-6 w-6 mr-3 text-primary" />
            Finding Your Perfect Vendors...
          </CardTitle>
          <p className="text-muted-foreground">
            We're curating the best sustainable vendors based on your requirements
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="grid gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border-0 bg-muted/30">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <Skeleton className="h-16 w-16 rounded-lg" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-5 w-1/3" />
                      <Skeleton className="h-4 w-1/2" />
                      <div className="flex space-x-2">
                        <Skeleton className="h-6 w-20" />
                        <Skeleton className="h-6 w-24" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-sm text-muted-foreground">This usually takes 30-60 seconds...</p>
          </div>
        </CardContent>
      </div>
    )
  }

  if (vendors.length === 0) {
    return (
      <div>
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Users className="h-6 w-6 mr-3 text-primary" />
            We're Expanding Our Network
          </CardTitle>
          <p className="text-muted-foreground">We're still building our vendor network in your area</p>
        </CardHeader>

        <CardContent className="space-y-6">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <Mail className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium mb-2">We'll follow up personally</h3>
                  <p className="text-sm text-muted-foreground">
                    Our team will reach out within 24-48 hours with handpicked vendor options for your area.
                  </p>
                </div>
                <Button onClick={onNext} className="mt-4">
                  Continue to Next Steps
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="flex items-center justify-between pt-6">
            <Button variant="outline" onClick={onBack}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Login
            </Button>
          </div>
        </CardContent>
      </div>
    )
  }

  return (
    <div>
      <CardHeader>
        <CardTitle className="flex items-center text-2xl">
          <Users className="h-6 w-6 mr-3 text-primary" />
          Your Curated Vendor List
        </CardTitle>
        <p className="text-muted-foreground">
          We found {getTotalVendorCount()} amazing sustainable vendors that match your needs
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Summary */}
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium mb-1">Ready to Connect</h3>
                <p className="text-sm text-muted-foreground">
                  All vendors are within 25km and specialize in sustainable practices
                </p>
              </div>
              <Button onClick={handleEmailVendors} disabled={emailSent} className="shrink-0">
                {emailSent ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Email Sent
                  </>
                ) : (
                  <>
                    <Mail className="h-4 w-4 mr-2" />
                    Email Me This List
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Vendor Cards */}
        <div className="space-y-4">
          {vendors.map((vendor) => (
            <Card key={vendor.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold text-lg">{vendor.name}</h3>
                        {vendor.verified && <CheckCircle className="h-5 w-5 text-green-500" />}
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                          {vendor.rating}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {vendor.location} • {vendor.distance} away
                        </div>
                      </div>
                    </div>
                    <Badge variant="secondary">{vendor.category}</Badge>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground">{vendor.description}</p>

                  {/* Specialties */}
                  <div>
                    <p className="text-sm font-medium mb-2">Specialties:</p>
                    <div className="flex flex-wrap gap-2">
                      {vendor.specialties.map((specialty) => (
                        <Badge key={specialty} variant="outline" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Sustainability Badges */}
                  <div>
                    <p className="text-sm font-medium mb-2">Sustainability Focus:</p>
                    <div className="flex flex-wrap gap-2">
                      {vendor.sustainabilityBadges.map((badge) => (
                        <Badge key={badge} className="text-xs bg-green-100 text-green-800 border-green-200">
                          <Leaf className="h-3 w-3 mr-1" />
                          {badge}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="text-sm text-muted-foreground">
                      <p className="font-medium">{vendor.priceRange}</p>
                      <p>{vendor.responseTime}</p>
                    </div>
                    <Button variant="outline" size="sm">
                      View Profile
                      <ExternalLink className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {emailSent && (
          <Card className="border-green-200 bg-green-50">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-3">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium text-green-800">Email sent successfully!</p>
                  <p className="text-sm text-green-600">
                    Check your inbox for the complete vendor list with contact details.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Login
          </Button>
          <Button onClick={onNext} size="lg" className="px-8">
            Continue to Next Steps
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </div>
  )
}
