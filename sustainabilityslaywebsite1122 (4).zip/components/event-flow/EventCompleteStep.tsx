"use client"

import { Button } from "../../components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card"
import { CheckCircle, Calendar, RefreshCw, FileText, MessageSquare, Sparkles } from "lucide-react"
import type { EventData } from "../EventPlanningFlow"

interface EventCompleteStepProps {
  data: EventData
  onComplete: () => void
  onRefine: () => void
}

export function EventCompleteStep({ data, onComplete, onRefine }: EventCompleteStepProps) {
  const handleConsultBooking = () => {
    // Navigate to consultation page
    window.location.href = "/consult"
  }

  const handleSavePDF = () => {
    // In real app, this would generate and download PDF
    alert("PDF generation would happen here")
  }

  const selectedServicesCount = data?.selectedServices?.length || 0
  const prioritiesCount = data?.priorities?.length || 0
  const guestsCount = data?.guests || 0

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
          <CheckCircle className="h-8 w-8 text-green-600" />
        </div>
        <CardTitle className="text-2xl">🎉 Your Sustainable Event Plan is Ready!</CardTitle>
        <p className="text-muted-foreground text-lg">
          You're all set to create an amazing event that's kind to the planet
        </p>
      </CardHeader>

      <CardContent className="space-y-8">
        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="text-center border-0 bg-primary/5">
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-primary">{selectedServicesCount}</div>
              <p className="text-sm text-muted-foreground">Service Categories</p>
            </CardContent>
          </Card>

          <Card className="text-center border-0 bg-primary/5">
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-primary">{prioritiesCount}</div>
              <p className="text-sm text-muted-foreground">Sustainability Goals</p>
            </CardContent>
          </Card>

          <Card className="text-center border-0 bg-primary/5">
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-primary">{guestsCount}</div>
              <p className="text-sm text-muted-foreground">Guests</p>
            </CardContent>
          </Card>

          <Card className="text-center border-0 bg-primary/5">
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-primary">3-5</div>
              <p className="text-sm text-muted-foreground">Curated Vendors</p>
            </CardContent>
          </Card>
        </div>

        {/* What Happens Next */}
        <Card className="border-0 bg-muted/30">
          <CardHeader>
            <CardTitle className="text-lg">What Happens Next?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  1
                </div>
                <div>
                  <h4 className="font-medium">Vendor Outreach</h4>
                  <p className="text-sm text-muted-foreground">
                    We'll introduce you to the selected vendors and help coordinate initial discussions.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  2
                </div>
                <div>
                  <h4 className="font-medium">Planning Support</h4>
                  <p className="text-sm text-muted-foreground">
                    Get ongoing guidance and tips to make your event as sustainable as possible.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium">
                  3
                </div>
                <div>
                  <h4 className="font-medium">Follow-up & Feedback</h4>
                  <p className="text-sm text-muted-foreground">
                    We'll check in after your event to hear how it went and gather feedback.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Button
              size="lg"
              onClick={handleConsultBooking}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Calendar className="mr-2 h-5 w-5" />
              Book a 30-min Consultation
            </Button>

            <Button variant="outline" size="lg" onClick={onRefine} className="w-full bg-transparent">
              <RefreshCw className="mr-2 h-5 w-5" />
              Refine Your Request
            </Button>
          </div>

          <Button variant="outline" onClick={handleSavePDF} className="w-full bg-transparent">
            <FileText className="mr-2 h-5 w-5" />
            Save as PDF (Coming Soon)
          </Button>
        </div>

        {/* Contact Info */}
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <h3 className="font-medium flex items-center justify-center">
                <MessageSquare className="h-4 w-4 mr-2" />
                Need Help?
              </h3>
              <p className="text-sm text-muted-foreground">
                Our team is here to support you throughout your planning journey.
              </p>
              <p className="text-sm">
                Email us at{" "}
                <a href="mailto:sustainandslay08@gmail.com" className="text-primary hover:underline">
                  sustainandslay08@gmail.com
                </a>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Final CTA */}
        <div className="text-center pt-6">
          <Button
            onClick={onComplete}
            size="lg"
            className="px-8 bg-gradient-to-r from-primary to-accent text-primary-foreground"
          >
            Complete & Return Home
            <Sparkles className="ml-2 h-5 w-5" />
          </Button>
        </div>

        {/* Thank You Note */}
        <div className="text-center pt-4 border-t">
          <p className="text-sm text-muted-foreground">Thank you for choosing sustainable event planning! 🌱</p>
        </div>
      </CardContent>
    </Card>
  )
}
