"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "../../components/ui/button"
import { Input } from "../../components/ui/input"
import { Label } from "../../components/ui/label"
import { CardContent, CardHeader, CardTitle } from "../../components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs"
import { ArrowLeft, Eye, EyeOff, User, Mail, Phone, Lock } from "lucide-react"

interface EventAuthStepProps {
  onSuccess: (user: {
    name: string
    email: string
    phone?: string
  }) => void
  onBack: () => void
}

export function EventAuthStep({ onSuccess, onBack }: EventAuthStepProps) {
  const [activeTab, setActiveTab] = useState("login")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)

  // Login form
  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")

  // Register form
  const [registerName, setRegisterName] = useState("")
  const [registerEmail, setRegisterEmail] = useState("")
  const [registerPhone, setRegisterPhone] = useState("")
  const [registerPassword, setRegisterPassword] = useState("")

  // Forgot password
  const [resetEmail, setResetEmail] = useState("")
  const [resetSent, setResetSent] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      // Mock successful login
      onSuccess({
        name: "User Name", // In real app, this would come from API
        email: loginEmail,
      })
    }, 1000)
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      // Mock successful registration
      onSuccess({
        name: registerName,
        email: registerEmail,
        phone: registerPhone,
      })
    }, 1000)
  }

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      setLoading(false)
      setResetSent(true)
    }, 1000)
  }

  const isLoginValid = loginEmail && loginPassword.length >= 8
  const isRegisterValid = registerName && registerEmail && registerPassword.length >= 8

  return (
    <div>
      <CardHeader>
        <CardTitle className="flex items-center text-2xl">
          <User className="h-6 w-6 mr-3 text-primary" />
          Create Account or Login
        </CardTitle>
        <p className="text-muted-foreground">
          We need to verify your details before revealing your curated vendor list
        </p>
      </CardHeader>

      <CardContent className="space-y-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Create Account</TabsTrigger>
          </TabsList>

          <TabsContent value="login" className="space-y-6 mt-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="login-email" className="flex items-center mb-2">
                  <Mail className="h-4 w-4 mr-2" />
                  Email Address
                </Label>
                <Input
                  id="login-email"
                  type="email"
                  placeholder="Enter your email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="login-password" className="flex items-center mb-2">
                  <Lock className="h-4 w-4 mr-2" />
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="login-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    required
                    minLength={8}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Minimum 8 characters</p>
              </div>

              <Button type="submit" className="w-full" disabled={!isLoginValid || loading}>
                {loading ? "Logging in..." : "Login"}
              </Button>
            </form>

            <div className="text-center">
              <Button
                variant="link"
                className="text-sm text-muted-foreground"
                onClick={() => {
                  // Show forgot password modal or inline form
                  const email = prompt("Enter your email address for password reset:")
                  if (email) {
                    setResetEmail(email)
                    handleForgotPassword({
                      preventDefault: () => {},
                    } as React.FormEvent)
                  }
                }}
              >
                Forgot password?
              </Button>
            </div>

            {resetSent && (
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800">Password reset instructions have been sent to your email.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="register" className="space-y-6 mt-6">
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <Label htmlFor="register-name" className="flex items-center mb-2">
                  <User className="h-4 w-4 mr-2" />
                  Full Name
                </Label>
                <Input
                  id="register-name"
                  type="text"
                  placeholder="Enter your full name"
                  value={registerName}
                  onChange={(e) => setRegisterName(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="register-email" className="flex items-center mb-2">
                  <Mail className="h-4 w-4 mr-2" />
                  Email Address
                </Label>
                <Input
                  id="register-email"
                  type="email"
                  placeholder="Enter your email"
                  value={registerEmail}
                  onChange={(e) => setRegisterEmail(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="register-phone" className="flex items-center mb-2">
                  <Phone className="h-4 w-4 mr-2" />
                  Phone Number (Optional)
                </Label>
                <Input
                  id="register-phone"
                  type="tel"
                  placeholder="Enter your phone number"
                  value={registerPhone}
                  onChange={(e) => setRegisterPhone(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="register-password" className="flex items-center mb-2">
                  <Lock className="h-4 w-4 mr-2" />
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="register-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Create a password"
                    value={registerPassword}
                    onChange={(e) => setRegisterPassword(e.target.value)}
                    required
                    minLength={8}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Must be at least 8 characters long</p>
              </div>

              <Button type="submit" className="w-full" disabled={!isRegisterValid || loading}>
                {loading ? "Creating Account..." : "Create Account"}
              </Button>
            </form>

            <div className="text-xs text-muted-foreground text-center space-y-2">
              <p>By creating an account, you agree to our terms of service and privacy policy.</p>
              <p>We'll only use your details to provide vendor recommendations for your events.</p>
            </div>
          </TabsContent>
        </Tabs>

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Review
          </Button>
          <div className="text-sm text-muted-foreground">Step 4 of 6</div>
        </div>
      </CardContent>
    </div>
  )
}
