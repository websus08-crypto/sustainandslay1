"use client"

import { useState } from "react"
import { Button } from "../ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card"
import { Badge } from "../ui/badge"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "../ui/sheet"
import { Checkbox } from "../ui/checkbox"
import {
  ArrowLeft,
  ArrowRight,
  Plus,
  Trash2,
  ShoppingCart,
  Palette,
  UtensilsCrossed,
  Gift,
  Shirt,
  Music,
  Camera,
  Truck,
  MapPin,
  Trash,
  Mail,
} from "lucide-react"
import type { EventData } from "../EventPlanningFlow"

interface EventServicesStepProps {
  data: EventData
  onUpdate: (updates: Partial<EventData>) => void
  onNext: () => void
  onBack: () => void
}

interface ServiceCategory {
  id: string
  name: string
  icon: any
  description: string
  subServices: string[]
}

const serviceCategories: ServiceCategory[] = [
  {
    id: "decor",
    name: "Decor",
    icon: Palette,
    description: "Sustainable decoration options including rentals, upcycled pieces, and eco-friendly materials",
    subServices: [
      "Rentable backdrop & arch",
      "Fabric drapes & linens",
      "Upcycled centerpieces",
      "Plant-based arrangements",
      "Reusable lighting setup",
      "Biodegradable confetti",
      "Vintage furniture rental",
    ],
  },
  {
    id: "catering",
    name: "Catering",
    icon: UtensilsCrossed,
    description: "Plant-forward menus, local sourcing, and zero-waste food service",
    subServices: [
      "Plant-forward menu planning",
      "Local & seasonal ingredients",
      "Compostable serving ware",
      "Food waste reduction plan",
      "Bulk beverage service",
      "Zero-plastic packaging",
      "Leftover donation coordination",
    ],
  },
  {
    id: "gifting",
    name: "Gifting",
    icon: Gift,
    description: "Meaningful, sustainable gift options and packaging alternatives",
    subServices: [
      "Experience-based gifts",
      "Local artisan products",
      "Plantable seed favors",
      "Reusable gift packaging",
      "Digital gift cards",
      "Charitable donations",
      "Upcycled welcome bags",
    ],
  },
  {
    id: "styling",
    name: "Outfits/Styling",
    icon: Shirt,
    description: "Sustainable fashion options including rentals and ethical brands",
    subServices: [
      "Outfit rental service",
      "Ethical fashion brands",
      "Vintage clothing options",
      "Accessories rental",
      "Sustainable fabric choices",
      "Local designer showcase",
      "Clothing swap coordination",
    ],
  },
  {
    id: "entertainment",
    name: "Entertainment",
    icon: Music,
    description: "Eco-conscious entertainment with minimal environmental impact",
    subServices: [
      "Acoustic music setups",
      "Local performer booking",
      "Solar-powered sound systems",
      "Interactive eco-activities",
      "Digital photo booth",
      "Nature-based games",
      "Community storytelling",
    ],
  },
  {
    id: "photography",
    name: "Photography",
    icon: Camera,
    description: "Digital-first photography with sustainable practices",
    subServices: [
      "Digital-only packages",
      "Drone photography",
      "Instant digital sharing",
      "Eco-friendly printing options",
      "Cloud storage solutions",
      "Social media optimization",
      "Virtual event coverage",
    ],
  },
  {
    id: "logistics",
    name: "Logistics/Transport",
    icon: Truck,
    description: "Carbon-conscious transportation and logistics coordination",
    subServices: [
      "Group transportation coordination",
      "Electric vehicle options",
      "Public transit guidance",
      "Carbon offset programs",
      "Local vendor prioritization",
      "Bike valet services",
      "Walking tour organization",
    ],
  },
  {
    id: "venue",
    name: "Venue",
    icon: MapPin,
    description: "Sustainable venues with eco-friendly facilities and practices",
    subServices: [
      "LEED certified venues",
      "Outdoor natural spaces",
      "Solar-powered facilities",
      "Zero-waste venues",
      "Accessible public transit",
      "Local community spaces",
      "Renewable energy options",
    ],
  },
  {
    id: "waste",
    name: "Waste Management",
    icon: Trash,
    description: "Comprehensive waste reduction and management solutions",
    subServices: [
      "Composting coordination",
      "Recycling station setup",
      "Waste audit services",
      "Reusable item collection",
      "Donation pickup services",
      "Zero-waste consultation",
      "Post-event cleanup",
    ],
  },
  {
    id: "invites",
    name: "Invites/Stationery",
    icon: Mail,
    description: "Digital-first invitations and sustainable paper alternatives",
    subServices: [
      "Digital invitation design",
      "QR code integration",
      "Seed paper invitations",
      "Recycled paper options",
      "Plantable stationery",
      "Digital RSVP management",
      "Virtual event platforms",
    ],
  },
]

export function EventServicesStep({ data, onUpdate, onNext, onBack }: EventServicesStepProps) {
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory | null>(null)
  const [selectedSubServices, setSelectedSubServices] = useState<string[]>([])
  const [isSheetOpen, setIsSheetOpen] = useState(false)

  const handleCategorySelect = (category: ServiceCategory) => {
    setSelectedCategory(category)
    // Check if this category is already in services
    const existingService = data.services.find((s) => s.category === category.name)
    setSelectedSubServices(existingService?.subServices || [])
    setIsSheetOpen(true)
  }

  const handleSubServiceToggle = (subService: string) => {
    setSelectedSubServices((prev) =>
      prev.includes(subService) ? prev.filter((s) => s !== subService) : [...prev, subService],
    )
  }

  const addToCart = () => {
    if (!selectedCategory) return

    const newServices = data.services.filter((s) => s.category !== selectedCategory.name)

    if (selectedSubServices.length > 0) {
      newServices.push({
        category: selectedCategory.name,
        subServices: selectedSubServices,
      })
    }

    onUpdate({ services: newServices })
    setIsSheetOpen(false)
    setSelectedCategory(null)
    setSelectedSubServices([])
  }

  const removeFromCart = (categoryName: string) => {
    const newServices = data.services.filter((s) => s.category !== categoryName)
    onUpdate({ services: newServices })
  }

  const getTotalServiceCount = () => {
    return data.services.reduce((total, service) => total + service.subServices.length, 0)
  }

  return (
    <div>
      <CardHeader>
        <CardTitle className="flex items-center text-2xl">
          <ShoppingCart className="h-6 w-6 mr-3 text-primary" />
          Select Services
        </CardTitle>
        <p className="text-muted-foreground">
          Choose the service categories you need for your event. Click each category to see specific options.
        </p>
      </CardHeader>

      <CardContent className="space-y-8">
        {/* Service Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {serviceCategories.map((category) => {
            const Icon = category.icon
            const isSelected = data.services.some((s) => s.category === category.name)
            const selectedCount = data.services.find((s) => s.category === category.name)?.subServices.length || 0

            return (
              <Card
                key={category.id}
                className={`cursor-pointer transition-all hover:shadow-md border-2 ${
                  isSelected ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                }`}
                onClick={() => handleCategorySelect(category)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`p-2 rounded-lg ${isSelected ? "bg-primary text-primary-foreground" : "bg-muted"}`}
                      >
                        <Icon className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-medium">{category.name}</h3>
                        {isSelected && selectedCount > 0 && (
                          <Badge variant="secondary" className="text-xs mt-1">
                            {selectedCount} selected
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Plus className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-muted-foreground line-clamp-2">{category.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Cart Summary */}
        {data.services.length > 0 && (
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Your Cart ({getTotalServiceCount()} items)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {data.services.map((service) => (
                  <div
                    key={service.category}
                    className="flex items-center justify-between bg-background/50 rounded-lg p-3"
                  >
                    <div>
                      <h4 className="font-medium">{service.category}</h4>
                      <p className="text-sm text-muted-foreground">
                        {service.subServices.length} service{service.subServices.length !== 1 ? "s" : ""} selected
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const category = serviceCategories.find((c) => c.name === service.category)
                          if (category) handleCategorySelect(category)
                        }}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFromCart(service.category)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Basics
          </Button>
          <Button onClick={onNext} size="lg" disabled={data.services.length === 0} className="px-8">
            Continue to Review
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </CardContent>

      {/* Service Selection Sheet */}
      <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          {selectedCategory && (
            <>
              <SheetHeader>
                <SheetTitle className="flex items-center">
                  <selectedCategory.icon className="h-5 w-5 mr-2" />
                  {selectedCategory.name}
                </SheetTitle>
                <SheetDescription>{selectedCategory.description}</SheetDescription>
              </SheetHeader>

              <div className="mt-6 space-y-4">
                <h4 className="font-medium">Select specific services:</h4>
                <div className="space-y-3">
                  {selectedCategory.subServices.map((subService) => (
                    <div key={subService} className="flex items-center space-x-3">
                      <Checkbox
                        id={subService}
                        checked={selectedSubServices.includes(subService)}
                        onCheckedChange={() => handleSubServiceToggle(subService)}
                      />
                      <label htmlFor={subService} className="text-sm font-medium leading-relaxed cursor-pointer flex-1">
                        {subService}
                      </label>
                    </div>
                  ))}
                </div>

                <div className="pt-6 flex space-x-3">
                  <Button onClick={addToCart} className="flex-1" disabled={selectedSubServices.length === 0}>
                    {selectedSubServices.length > 0
                      ? `Add ${selectedSubServices.length} Service${selectedSubServices.length !== 1 ? "s" : ""}`
                      : "Select Services"}
                  </Button>
                  <Button variant="outline" onClick={() => setIsSheetOpen(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}
