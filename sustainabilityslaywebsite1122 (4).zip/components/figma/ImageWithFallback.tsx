"use client"

import { useState } from "react"
import { cn } from "../../lib/utils"

interface ImageWithFallbackProps {
  src: string
  alt: string
  className?: string
  fallback?: string
}

export function ImageWithFallback({
  src,
  alt,
  className,
  fallback = "/placeholder.svg?height=400&width=600",
}: ImageWithFallbackProps) {
  const [imgSrc, setImgSrc] = useState(src)
  const [hasError, setHasError] = useState(false)

  const handleError = () => {
    if (!hasError) {
      setHasError(true)
      setImgSrc(fallback)
    }
  }

  return (
    <img src={imgSrc || "/placeholder.svg"} alt={alt} className={cn("object-cover", className)} onError={handleError} />
  )
}
