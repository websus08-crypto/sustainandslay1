"use client"

import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Leaf, Users, Calendar, ArrowRight, Calculator, Sparkles } from "lucide-react"

type HomePageProps = {}

export function HomePage({}: HomePageProps) {
  const handleNavigation = (view: string) => {
    if ((window as any).navigateTo) {
      ;(window as any).navigateTo(view)
    }
  }

  const howItWorksSteps = [
    {
      icon: Calendar,
      title: "Plan",
      description: "Pick your event type and sustainability goals",
    },
    {
      icon: Users,
      title: "Select",
      description: "Add curated eco-friendly services to your cart",
    },
    {
      icon: Leaf,
      title: "See Vendors",
      description: "Login to reveal your personalized vendor list",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 gradient-leaf-sage opacity-5"></div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-display font-display font-bold text-foreground mb-6">
              Making events stylish, sustainable, and guilt‑free.
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              Plan beautiful celebrations that honor both your vision and the planet. Discover curated vendors who make
              sustainability effortless and elegant.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => handleNavigation("events")}
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg"
              >
                Plan an Event
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => handleNavigation("solutions")}
                className="border-primary text-primary hover:bg-primary/10 px-8 py-4 text-lg bg-transparent"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-h2 font-display font-semibold text-foreground mb-4">How It Works</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Three simple steps to create an amazing event that's kind to the planet
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {howItWorksSteps.map((step, index) => (
              <Card key={index} className="text-center border-0 shadow-sm bg-background/80 backdrop-blur">
                <CardHeader>
                  <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <step.icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{step.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{step.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Calculator Teaser */}
      <section className="py-20 bg-accent/20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <Card className="border-0 shadow-lg bg-background/90 backdrop-blur">
            <CardHeader>
              <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Calculator className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Estimate Your Event's Impact</CardTitle>
              <CardDescription className="text-lg">
                Discover how your choices affect the environment in just 60 seconds
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button size="lg" disabled className="bg-muted text-muted-foreground cursor-not-allowed">
                Coming Soon
                <Sparkles className="ml-2 h-5 w-5" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-h2 font-display font-semibold mb-4">Ready to Plan Your Sustainable Event?</h2>
          <p className="text-lg mb-8 opacity-90">Get personalized guidance from our sustainability experts</p>
          <Button
            size="lg"
            variant="outline"
            onClick={() => handleNavigation("consult")}
            className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
          >
            Book a Consultation
          </Button>
        </div>
      </section>
    </div>
  )
}
