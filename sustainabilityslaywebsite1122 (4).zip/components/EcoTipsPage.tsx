"use client"

import { Button } from "./ui/button"
import { Card, CardContent } from "./ui/card"

type EcoTipsPageProps = {}

export default function EcoTipsPage({}: EcoTipsPageProps) {
  // Internal navigation function
  const handleNavigation = (view: string) => {
    if ((window as any).navigateTo) {
      ;(window as any).navigateTo(view)
    }
  }

  return (
    <div>
      {/* Hero Section */}
      <section className="py-20 bg-secondary">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-h1 font-display font-semibold mb-6">EcoTips</h1>
          <p className="text-lg text-muted-foreground">
            Discover sustainable celebration ideas, tips, and inspiration for planet-positive events.
          </p>
        </div>
      </section>

      {/* Featured Blog Post */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <article className="prose prose-lg max-w-none">
            <header className="mb-12 text-center">
              <h2 className="text-h2 font-display font-semibold mb-4 text-primary text-balance">
                The Celebration That Lasts Longer Than a Night...
              </h2>
              <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                <span>Featured Article</span>
                <span>•</span>
                <span>Sustainable Celebrations</span>
              </div>
            </header>

            <div className="space-y-8 text-foreground leading-relaxed">
              <p className="text-lg">
                Making memories is India's favourite language: cousins tumbling out of dawn trains, aunties debating the
                perfect laddoo, the dhol shaking the street awake until neighbours gather at the gate with smiles. Here,
                joy is not once-a-year, it is all year, stitched into calendars, shared like prasad, open to everyone
                who passes by.
              </p>

              <p>
                But once the lights dim and playlists fade, another scene unfolds: sacks of plastic plates, mountains of
                wilting flowers, heaps of half-eaten food, and trucks packed with mixed waste. A typical wedding of a
                few hundred guests can generate 2–3 tonnes of waste across just three days. That's not "just a party",
                that's a small city's footprint, created overnight.
              </p>

              <p>
                India's Solid Waste Management Rules already recognise this reality. Any event producing more than 100
                kg of waste a day is legally a bulk waste generator, expected to segregate and responsibly process its
                waste. In other words, weddings and festivals aren't small, private affairs anymore; they operate at
                industrial scale whether we realise it or not.
              </p>

              <p className="text-xl font-medium text-primary italic text-center py-4">
                And yet, the answer isn't to shrink our joy. It's to choose joy that lasts longer than a single evening.
              </p>

              <div className="bg-secondary/50 rounded-lg p-8 my-12">
                <h3 className="text-xl font-semibold mb-6 text-primary">Reusables: Our Forgotten Tradition</h3>

                <p className="mb-6">
                  Our own history shows us the way. For generations, India's celebrations were naturally low-waste:
                </p>

                <div className="space-y-4 mb-6">
                  <p>
                    South Indian weddings served feasts on banana leaves, folded neatly back into the soil as compost
                    the next morning. Steel tumblers of water circled endlessly, and nothing was "use and throw."
                  </p>

                  <p>
                    Village festivals used clay diyas, handmade rangolis, brass lamps, and fabric pandals stitched from
                    cotton sheets items that lived many lives, not just one.
                  </p>
                </div>

                <p className="font-medium">
                  None of this felt like compromise it felt abundant, welcoming, rooted. Guests ate, laughed, and
                  abundant, welcoming, rooted. Switching from single-use to reusable is not a burden; it's a return to
                  our roots with a modern shine.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-12">
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-6">
                      <h4 className="font-semibold mb-3 text-primary">Cutlery & Plates</h4>
                      <p className="text-sm">
                        Renting steel or glassware eliminates waste and elevates dining. Guests eat comfortably, servers
                        move easily, and not a single trash bag fills with soggy disposables.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-6">
                      <h4 className="font-semibold mb-3 text-primary">Décor</h4>
                      <p className="text-sm">
                        Fabric drapes, brass lamps, terracotta pots, and live plants look richer than plastic and can be
                        reused across years of celebrations.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-6">
                      <h4 className="font-semibold mb-3 text-primary">Serving & Storage</h4>
                      <p className="text-sm">
                        Steel tumblers, water dispensers, and durable trays make hydration and food service cleaner and
                        cheaper in the long run.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-6">
                      <h4 className="font-semibold mb-3 text-primary">Flowers & Rituals</h4>
                      <p className="text-sm">
                        Marigolds, mango leaves, and clay can be composted or reused in rituals the next day instead of
                        choking drains.
                      </p>
                    </CardContent>
                  </Card>
                </div>

                <p>
                  In India, celebration has always been about showing care for your guests. Today, that care extends
                  beyond what's served on the plate; it includes what happens to the plate itself. A host who chooses
                  reusable cutlery, compostable décor, and pooled transport isn't just throwing a party. They're setting
                  a new standard of hospitality: joy without harm.
                </p>

                <div className="bg-primary/10 rounded-lg p-8 my-12 text-center">
                  <h3 className="text-xl font-semibold mb-4 text-primary">
                    At Sustain & Slay, together we can design events that breathe!
                  </h3>

                  <div className="text-left max-w-2xl mx-auto">
                    <p className="mb-4 font-medium">The formula can be simple:</p>
                    <ul className="space-y-2 text-sm">
                      <li>• Design for reusables first: steel, glass, cloth, and clay.</li>
                      <li>
                        • Compostables only where composting is real: banana leaves, flowers, paper that's actually
                        collected.
                      </li>
                      <li>• Confirm segregation and processing before the invitations go out.</li>
                      <li>• Right-size menus and lock in donations for surplus food.</li>
                      <li>• Cut kilometres, not guests: choose closer venues and shared transport.</li>
                    </ul>
                  </div>
                </div>

                <p>
                  When we do this, a celebration stops being a bulk waste event and becomes a living memory: the music
                  fades, the joy lingers, and the ground looks as if it were respected, not used up.
                </p>

                <p className="text-lg font-medium text-center py-6 text-primary">
                  Because in the end, what guests remember is not the pile of plates behind the tent, but the warmth of
                  being welcomed. Let our gatherings be abundant in joy, generous in care, and light in their footprint,
                  so the memories outlast the waste.
                </p>
              </div>
            </div>
          </article>

          {/* Call to Action */}
          <div className="mt-16 text-center">
            <div className="bg-secondary rounded-lg p-8">
              <h3 className="text-xl font-semibold mb-4 text-primary">Ready to plan your sustainable celebration?</h3>
              <p className="text-muted-foreground mb-6">
                Let us help you create an event that's abundant in joy and light in its footprint.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={() => handleNavigation("events")}
                  className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
                >
                  Plan Your Event
                </Button>
                <Button
                  onClick={() => handleNavigation("consult")}
                  variant="outline"
                  className="px-6 py-3 border-primary text-primary rounded-lg hover:bg-primary/10 bg-transparent"
                >
                  Get Consultation
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
