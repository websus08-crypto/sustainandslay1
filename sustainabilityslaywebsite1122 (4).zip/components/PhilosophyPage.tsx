"use client"

import { Button } from "./ui/button"
import { Card, CardContent } from "./ui/card"

type PhilosophyPageProps = {}

export default function PhilosophyPage({}: PhilosophyPageProps) {
  const handleNavigation = (view: string) => {
    if ((window as any).navigateTo) {
      ;(window as any).navigateTo(view)
    }
  }

  return (
    <div>
      {/* Hero Section */}
      <section className="py-20 bg-secondary">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-h1 font-display font-semibold mb-6 text-balance">Philosophy & Solution</h1>
          <div className="max-w-2xl mx-auto space-y-4 text-lg text-muted-foreground">
            <p>You care about the environment.</p>
            <p>You've heard about climate change.</p>
            <p>You feel the urgency, but let's be honest... planning a celebration is already enough stress.</p>
            <p className="text-xl font-medium text-primary italic">
              "How can I make it eco-friendly without losing the magic?"
            </p>
            <p>That's the question we kept hearing, and it's exactly why we created this platform.</p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-h2 font-display font-semibold mb-6 text-primary">
              💚 The Idea That Sparked a Movement
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A bunch of curious, climate-conscious dreamers (that's us!) came together and asked:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <Card className="border border-border/20 shadow-lg bg-card/50 hover:shadow-xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <h3 className="font-semibold text-lg mb-4">
                  What if events could be joyful and planet-positive at the same time?
                </h3>
              </CardContent>
            </Card>
            <Card className="border border-border/20 shadow-lg bg-card/50 hover:shadow-xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <h3 className="font-semibold text-lg mb-4">What if weddings didn't leave behind waste?</h3>
              </CardContent>
            </Card>
            <Card className="border border-border/20 shadow-lg bg-card/50 hover:shadow-xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <h3 className="font-semibold text-lg mb-4">
                  What if birthdays felt just as grand, but with a lighter footprint?
                </h3>
              </CardContent>
            </Card>
            <Card className="border border-border/20 shadow-lg bg-card/50 hover:shadow-xl transition-all duration-300 hover:scale-105">
              <CardContent className="p-8 text-center">
                <h3 className="font-semibold text-lg mb-4">
                  What if you could throw the party of your dreams and feel proud of the impact you made?
                </h3>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <p className="text-lg text-muted-foreground">
              So we built the first-of-its-kind platform that makes planning an eco-conscious event easy, exciting, and
              entirely yours.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-muted/20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-h2 font-display font-semibold mb-6 text-primary">How It Works:</h2>
          </div>

          <div className="space-y-16">
            {/* Step 1 */}
            <div className="flex flex-col lg:flex-row items-center gap-8">
              <div className="lg:w-1/5 flex justify-center">
                <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-2xl shadow-lg">
                  1
                </div>
              </div>
              <div className="lg:w-4/5 text-center lg:text-left">
                <h3 className="text-2xl font-semibold mb-4 text-primary">Tell Us About Your Event</h3>
                <p className="text-muted-foreground text-lg">
                  Planning a wedding? A birthday? A work retreat? Just choose your event type, budget, and guest count.
                  That's it.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex flex-col lg:flex-row-reverse items-center gap-8">
              <div className="lg:w-1/5 flex justify-center">
                <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground font-bold text-2xl shadow-lg">
                  2
                </div>
              </div>
              <div className="lg:w-4/5 text-center lg:text-right">
                <h3 className="text-2xl font-semibold mb-4 text-primary">Explore Green-Ready Vendors</h3>
                <p className="text-muted-foreground text-lg">
                  We've got a curated list of amazing vendors - caterers, venues, decorators, photographers who are
                  already eco-friendly or open to becoming one for you. You'll see what sustainable practices they offer
                  and how they fit your budget.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex flex-col lg:flex-row items-center gap-8">
              <div className="lg:w-1/5 flex justify-center">
                <div className="w-20 h-20 bg-accent rounded-full flex items-center justify-center text-accent-foreground font-bold text-2xl shadow-lg">
                  3
                </div>
              </div>
              <div className="lg:w-4/5 text-center lg:text-left">
                <h3 className="text-2xl font-semibold mb-4 text-primary">Mix, Match & Customise Your Impact</h3>
                <p className="text-muted-foreground text-lg">
                  Like the idea of local flowers? Digital invites? Reusable cutlery? Add it to your cart, tweak it,
                  explore combinations — and we'll show you how much waste, water, and carbon you'll save by making just
                  a few small swaps.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex flex-col lg:flex-row-reverse items-center gap-8">
              <div className="lg:w-1/5 flex justify-center">
                <div className="w-20 h-20 bg-primary/80 rounded-full flex items-center justify-center text-primary-foreground font-bold text-2xl shadow-lg">
                  4
                </div>
              </div>
              <div className="lg:w-4/5 text-center lg:text-right">
                <h3 className="text-2xl font-semibold mb-4 text-primary">
                  Can't Go Fully Green? You Still Make a Difference.
                </h3>
                <p className="text-muted-foreground text-lg mb-4">
                  Not everything may work out — and that's okay. You can still give back by:
                </p>
                <ul className="space-y-3 text-muted-foreground text-lg">
                  <li className="flex items-center justify-center lg:justify-end gap-3">
                    <span>🌳</span> Donating to tree plantations
                  </li>
                  <li className="flex items-center justify-center lg:justify-end gap-3">
                    <span>🍲</span> Supporting food donation or composting
                  </li>
                  <li className="flex items-center justify-center lg:justify-end gap-3">
                    <span>♻️</span> Contributing to local recycling initiatives
                  </li>
                </ul>
                <p className="text-muted-foreground mt-4 font-medium text-lg">Even one small step makes an impact.</p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex flex-col lg:flex-row items-center gap-8">
              <div className="lg:w-1/5 flex justify-center">
                <div className="w-20 h-20 bg-secondary/80 rounded-full flex items-center justify-center text-secondary-foreground font-bold text-2xl shadow-lg">
                  5
                </div>
              </div>
              <div className="lg:w-4/5 text-center lg:text-left">
                <h3 className="text-2xl font-semibold mb-4 text-primary">
                  Celebrate Consciously - and Get a Badge of Honour
                </h3>
                <p className="text-muted-foreground text-lg">
                  After your event, you'll receive a beautiful Eco Impact Certificate showing how your choices helped
                  the planet. It's something to be proud of and to inspire others.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Closing Section */}
      <section className="py-20 bg-primary">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-h2 font-display font-semibold mb-8 text-primary-foreground">
            A New Kind of Celebration Starts Here
          </h2>

          <div className="space-y-6 text-primary-foreground/90 text-lg max-w-2xl mx-auto">
            <p>This isn't just about planning an event.</p>
            <p>This is about starting a ripple - one conscious choice at a time.</p>
            <p>It's about redefining what a celebration can mean.</p>

            <div className="py-8">
              <p className="text-xl font-semibold text-primary-foreground">Not less, but more:</p>
              <div className="mt-4 space-y-2">
                <p>More intentional. More soulful. More beautiful.</p>
              </div>
            </div>

            <p className="text-xl font-medium text-primary-foreground">
              Because joy shouldn&#39;t come at the planet&#39;s expense and now, it doesn&#39;t have to.
            </p>
          </div>

          <div className="mt-12">
            <Button
              onClick={() => handleNavigation("consult")}
              size="lg"
              className="px-8 py-4 bg-primary-foreground text-primary font-medium rounded-xl hover:bg-primary-foreground/90 transition-colors"
            >
              Start Your Sustainable Event Journey
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
