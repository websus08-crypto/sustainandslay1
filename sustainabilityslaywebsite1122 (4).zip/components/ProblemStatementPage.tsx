"use client"

import { Button } from "./ui/button"
import { Card, CardContent } from "./ui/card"
import { Badge } from "./ui/badge"
import { AlertTriangle, Globe, Zap, Utensils, Trash2, Droplets, Car, Thermometer } from "lucide-react"
import { useEffect, useState, useRef } from "react"

type ProblemStatementPageProps = {}

function useCountAnimation(end: number, duration = 2000) {
  const [count, setCount] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true)
          let start = 0
          const increment = end / (duration / 16)
          const timer = setInterval(() => {
            start += increment
            if (start >= end) {
              setCount(end)
              clearInterval(timer)
            } else {
              setCount(Math.floor(start))
            }
          }, 16)
        }
      },
      { threshold: 0.5 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [end, duration, isVisible])

  return { count, ref }
}

function useScrollAnimation() {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { isVisible, ref }
}

export function ProblemStatementPage({}: ProblemStatementPageProps) {
  const handleNavigation = (view: string) => {
    if ((window as any).navigateTo) {
      ;(window as any).navigateTo(view)
    }
  }

  const statistics = [
    {
      icon: <Zap className="h-8 w-8 text-yellow-500" />,
      number: "2-3",
      numericValue: 3,
      label: "Months of family electricity used per event",
      description: "A full-day wedding uses as much electricity as a family uses in 2-3 months",
    },
    {
      icon: <Utensils className="h-8 w-8 text-orange-500" />,
      number: "300",
      numericValue: 300,
      label: "Kg of food wasted per event",
      description: "30-40% of food goes uneaten, producing methane gas 25x worse than CO₂",
    },
    {
      icon: <Trash2 className="h-8 w-8 text-red-500" />,
      number: "5000",
      numericValue: 5000,
      label: "Plastic items used per event",
      description: "Single-use plates, cutlery, cups - enough to fill a small car",
    },
    {
      icon: <Droplets className="h-8 w-8 text-blue-500" />,
      number: "20000",
      numericValue: 20000,
      label: "Litres of water used per event",
      description: "Drinking water for 300 people for a whole month",
    },
  ]

  const challenges = [
    {
      title: "Massive Energy Consumption",
      description:
        "Events consume enormous amounts of electricity - a single wedding uses as much power as running an AC non-stop for 3 weeks.",
      icon: <Zap className="h-6 w-6 text-yellow-500" />,
    },
    {
      title: "Food Waste Crisis",
      description:
        "30-40% of food at Indian events goes uneaten, ending up in landfills where it produces methane - 25x worse than CO₂.",
      icon: <Utensils className="h-6 w-6 text-orange-500" />,
    },
    {
      title: "Plastic Pollution",
      description:
        "2,000-5,000 single-use plastic items per event, mostly ending up in landfills, drains, or being burned.",
      icon: <Trash2 className="h-6 w-6 text-red-500" />,
    },
    {
      title: "Decor Waste",
      description: "100-200 kg of decor waste per event, much of it non-biodegradable, lasting hundreds of years.",
      icon: <Globe className="h-6 w-6 text-green-500" />,
    },
    {
      title: "Water Wastage",
      description: "10,000-20,000 litres used per event - enough to fill two small swimming pools.",
      icon: <Droplets className="h-6 w-6 text-blue-500" />,
    },
    {
      title: "Travel Emissions",
      description:
        "A 100-guest wedding emits 30 tonnes of CO₂ from travel alone - equal to 16-19 households' annual emissions.",
      icon: <Car className="h-6 w-6 text-purple-500" />,
    },
  ]

  const heroAnimation = useScrollAnimation()
  const statsAnimation = useScrollAnimation()
  const challengesAnimation = useScrollAnimation()
  const impactAnimation = useScrollAnimation()
  const solutionAnimation = useScrollAnimation()

  const count1 = useCountAnimation(3, 2000)
  const count2 = useCountAnimation(300, 2000)
  const count3 = useCountAnimation(5000, 2000)
  const count4 = useCountAnimation(20000, 2000)

  const countAnimations = [count1, count2, count3, count4]

  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--color-off-white)] to-[var(--color-sand)] overflow-hidden">
      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div
          ref={heroAnimation.ref}
          className={`mx-auto max-w-4xl text-center transition-all duration-1000 ${
            heroAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <Badge
            variant="outline"
            className={`mb-6 text-sm font-medium transition-all duration-700 delay-300 border-primary text-primary ${
              heroAnimation.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
            }`}
          >
            The Environmental Crisis in Events
          </Badge>
          <h1
            className={`text-4xl font-bold text-foreground mb-6 text-balance transition-all duration-1000 delay-500 font-display md:text-4xl ${
              heroAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            Your Celebration's Hidden Environmental Cost
          </h1>
          <p
            className={`text-xl text-muted-foreground mb-8 text-pretty max-w-3xl mx-auto transition-all duration-1000 delay-700 ${
              heroAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            Every wedding, corporate event, and celebration in India leaves a massive environmental footprint. From
            energy consumption to food waste, the numbers are staggering - and the impact is immediate.
          </p>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="mx-auto max-w-7xl">
          <div
            ref={statsAnimation.ref}
            className={`transition-all duration-1000 ${
              statsAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <h2 className="text-3xl font-bold text-center mb-4 text-balance font-display text-foreground">
              Impact Per Event
            </h2>
            <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
              These aren't global statistics - this is what happens at every single event in India
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {statistics.map((stat, index) => {
              const countAnimation = countAnimations[index]
              return (
                <div
                  key={index}
                  ref={countAnimation.ref}
                  className={`transition-all duration-700 ${
                    statsAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                  }`}
                  style={{ transitionDelay: `${index * 200}ms` }}
                >
                  <Card className="text-center p-6 hover:shadow-xl hover:scale-105 transition-all duration-300 group bg-card border-border">
                    <CardContent className="space-y-4">
                      <div className="flex justify-center group-hover:scale-110 transition-transform duration-300">
                        {stat.icon}
                      </div>
                      <div className="text-3xl font-bold text-foreground font-display">
                        {countAnimation.count.toLocaleString()}
                        {stat.number.includes("Kg")
                          ? " Kg"
                          : stat.number.includes("Litres")
                            ? " L"
                            : stat.number.includes("Months")
                              ? " Months"
                              : ""}
                      </div>
                      <div className="font-semibold text-secondary-foreground text-sm">{stat.label}</div>
                      <p className="text-xs text-muted-foreground text-pretty">{stat.description}</p>
                    </CardContent>
                  </Card>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Climate Impact Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-muted to-secondary">
        <div className="mx-auto max-w-6xl">
          <div
            ref={challengesAnimation.ref}
            className={`transition-all duration-1000 mb-12 ${
              challengesAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <h2 className="text-3xl font-bold text-center mb-6 text-balance font-display text-foreground">
              How Climate Change Affects Us - Everyday, in India
            </h2>
            <p className="text-center text-muted-foreground max-w-3xl mx-auto">
              We no longer need scientific graphs to understand climate change, we can feel it around us
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {[
              {
                icon: <Thermometer className="h-8 w-8 text-red-500" />,
                title: "45°C+ Heatwaves",
                desc: "Delhi, Nagpur, Ahmedabad",
              },
              {
                icon: <Droplets className="h-8 w-8 text-blue-500" />,
                title: "Devastating Floods",
                desc: "Mumbai, Bengaluru, Chennai",
              },
              {
                icon: <Utensils className="h-8 w-8 text-green-500" />,
                title: "Crop Losses",
                desc: "Affecting food prices",
              },
              {
                icon: <AlertTriangle className="h-8 w-8 text-orange-500" />,
                title: "Air Pollution",
                desc: "Public health risks",
              },
            ].map((item, index) => (
              <div
                key={index}
                className={`text-center p-4 transition-all duration-700 hover:scale-105 ${
                  challengesAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <div className="flex justify-center mb-3">{item.icon}</div>
                <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Impact Breakdown */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <div
            className={`transition-all duration-1000 mb-12 ${
              challengesAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <h2 className="text-3xl font-bold text-center mb-12 text-balance font-display text-foreground">
              The Hidden Environmental Cost of Every Celebration
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {challenges.map((challenge, index) => (
              <div
                key={index}
                className={`transition-all duration-700 ${
                  challengesAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <Card className="p-6 hover:shadow-xl hover:scale-105 transition-all duration-300 group h-full bg-card border-border">
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="group-hover:scale-110 transition-transform duration-300">{challenge.icon}</div>
                      <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors duration-300 font-display">
                        {challenge.title}
                      </h3>
                    </div>
                    <p className="text-muted-foreground text-pretty">{challenge.description}</p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Waste Impact Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-destructive/10 to-destructive/20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-destructive/5 via-destructive/10 to-destructive/5 animate-pulse opacity-50"></div>
        <div className="mx-auto max-w-4xl text-center relative z-10">
          <div
            ref={impactAnimation.ref}
            className={`transition-all duration-1000 ${
              impactAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <h2 className="text-3xl font-bold mb-8 text-balance font-display text-foreground">India's Waste Crisis</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-3xl mx-auto">
              India generates over 62 million tonnes of waste each year, expected to double by 2030. Most ends up in
              landfills, causing serious environmental damage.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {[
              {
                title: "Methane Emissions",
                description: "Food waste decomposes without oxygen, releasing methane - 25x more potent than CO₂",
                icon: <Utensils className="h-8 w-8 text-orange-500" />,
              },
              {
                title: "Toxic Pollution",
                description: "Plastic gets burned or dumped, polluting air and soil with toxic emissions",
                icon: <Trash2 className="h-8 w-8 text-red-500" />,
              },
              {
                title: "No Recovery",
                description: "Lack of recycling systems means most waste isn't recovered or reused",
                icon: <AlertTriangle className="h-8 w-8 text-yellow-500" />,
              },
            ].map((item, index) => (
              <div
                key={index}
                className={`space-y-4 transition-all duration-700 hover:scale-105 ${
                  impactAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                <div className="flex justify-center">{item.icon}</div>
                <div className="text-xl font-bold text-red-600 hover:text-red-700 transition-colors duration-300">
                  {item.title}
                </div>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Solution Teaser */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-primary via-accent to-primary text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-transparent via-white to-transparent animate-pulse"></div>
        </div>
        <div className="mx-auto max-w-4xl text-center relative z-10">
          <div
            ref={solutionAnimation.ref}
            className={`transition-all duration-1000 ${
              solutionAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
            }`}
          >
            <h2 className="text-3xl font-bold mb-6 text-balance font-display">But There's Hope</h2>
            <p className="text-xl mb-8 text-pretty">
              Sustainable events don't have to be complicated or expensive. With the right guidance, tools, and vendor
              network, you can create beautiful celebrations that honor both your vision and the planet.
            </p>
            <div
              className={`flex flex-col sm:flex-row gap-4 justify-center transition-all duration-1000 delay-500 ${
                solutionAnimation.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
              }`}
            >
              <Button
                onClick={() => handleNavigation("solutions")}
                size="lg"
                variant="secondary"
                className="bg-background text-primary hover:bg-muted hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Discover Our Solutions
              </Button>
              <Button
                onClick={() => handleNavigation("consult")}
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Get Expert Consultation
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default ProblemStatementPage
