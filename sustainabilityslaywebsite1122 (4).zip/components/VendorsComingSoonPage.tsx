"use client"

import { Button } from "./ui/button"
import { ArrowLeft, Clock, Bell, Sparkles } from "lucide-react"

interface VendorsComingSoonPageProps {
  onBack?: () => void
}

export default function VendorsComingSoonPage({ onBack }: VendorsComingSoonPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-br from-green-50 to-teal-50 border-b">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center gap-4 mb-6">
            <Button variant="ghost" size="sm" onClick={onBack} className="hover:bg-white/50">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          </div>
        </div>
      </div>

      {/* Coming Soon Content */}
      <div className="py-24">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <Clock className="h-12 w-12 text-primary animate-pulse" />
            <Sparkles className="h-8 w-8 text-yellow-500" />
          </div>

          <h1 className="text-5xl md:text-6xl font-display text-primary mb-6">Vendors Coming Soon</h1>

          <p className="text-xl text-muted-foreground mb-12 leading-relaxed max-w-2xl mx-auto">
            We're carefully curating the best sustainable vendors and eco-friendly suppliers to bring you the highest
            quality products for your events and daily life.
          </p>

          <div className="bg-gradient-to-br from-green-100 to-teal-100 rounded-3xl p-8 mb-12">
            <Bell className="h-8 w-8 text-primary mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-primary mb-4">Get Notified</h2>
            <p className="text-muted-foreground mb-6">
              Be the first to know when our vendor marketplace launches with exclusive early access.
            </p>
            <Button className="btn-primary text-lg px-8 py-3">Notify Me When Ready</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">🌱</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Verified Sustainable</h3>
              <p className="text-sm text-muted-foreground">
                Every vendor is thoroughly vetted for their environmental practices and sustainability credentials.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">⭐</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Quality Assured</h3>
              <p className="text-sm text-muted-foreground">
                We partner only with vendors who meet our high standards for product quality and service excellence.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm border">
              <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center mb-4">
                <span className="text-2xl">🤝</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">Fair Trade</h3>
              <p className="text-sm text-muted-foreground">
                Supporting ethical business practices and fair compensation throughout the supply chain.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
