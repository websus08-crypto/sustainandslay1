"use client"

import { Button } from "./ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card"
import { Input } from "./ui/input"
import { Label } from "./ui/label"

type ConsultPageProps = {}

export default function ConsultPage({}: ConsultPageProps) {
  return (
    <div>
      <section className="py-20 bg-muted/20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-h1 font-display font-semibold mb-6 text-balance">
              Enquire about our services or ask us about our sustainability consulting, and we'll get back to you
              shortly!
            </h1>
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8">
              **WE DO NOT SHARE DATA WITH ANY THIRD PARTIES.**
            </div>
          </div>

          <Card className="border-0 shadow-xl bg-background/90 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-primary font-medium">Contact Us</CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-primary font-medium">
                      Your name *
                    </Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Name"
                      required
                      className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-primary font-medium">
                      Email *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="name@example.com"
                      required
                      className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="location" className="text-primary font-medium">
                      Location *
                    </Label>
                    <Input
                      id="location"
                      type="text"
                      placeholder="Which city?"
                      required
                      className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-primary font-medium">
                      Phone *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="Enter your phone number"
                      required
                      className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="enquiry-type" className="text-primary font-medium">
                      Enquiring about *
                    </Label>
                    <select
                      id="enquiry-type"
                      required
                      className="h-12 w-full rounded-xl border-2 border-border focus:border-primary transition-colors bg-background px-3 text-foreground"
                    >
                      <option value="">Choose an option</option>
                      <option value="event-planning">Full Event Planning</option>
                      <option value="sustainability-consulting">Sustainability Consulting</option>
                      <option value="vendor-network">Vendor Network Access</option>
                      <option value="impact-assessment">Event Impact Assessment</option>
                      <option value="corporate-events">Corporate Event Services</option>
                      <option value="wedding-planning">Sustainable Wedding Planning</option>
                      <option value="other">Other Services</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-primary font-medium">
                      Your message *
                    </Label>
                    <textarea
                      id="message"
                      placeholder="I need Sustain & Slay's help for..."
                      required
                      rows={4}
                      className="w-full rounded-xl border-2 border-border focus:border-primary transition-colors bg-background px-3 py-3 text-foreground resize-none"
                    />
                  </div>
                </div>

                <div className="pt-6">
                  <Button
                    type="submit"
                    size="lg"
                    className="w-full md:w-auto px-12 py-4 bg-secondary hover:bg-secondary/90 text-secondary-foreground rounded-xl font-medium text-lg"
                  >
                    Send Enquiry
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Additional Information Section */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="font-semibold mb-2">Quick Response</h3>
                <p className="text-sm text-muted-foreground">
                  We typically respond within 24 hours to all consultation requests.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9 12l2 2 4-4m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="font-semibold mb-2">Free Consultation</h3>
                <p className="text-sm text-muted-foreground">
                  Initial consultations are complimentary to understand your sustainability goals.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg text-center">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                    />
                  </svg>
                </div>
                <h3 className="font-semibold mb-2">Personalized Approach</h3>
                <p className="text-sm text-muted-foreground">
                  Every event is unique. We tailor our services to your specific needs and values.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
