"use client"

import { useState, useEffect, Suspense, lazy } from "react"

const HomePage = lazy(() => import("./HomePage").then((module) => ({ default: module.HomePage })))
const EventPlanningFlow = lazy(() =>
  import("./EventPlanningFlow").then((module) => ({ default: module.EventPlanningFlow })),
)
const VendorsPage = lazy(() => import("./VendorsPage"))
const PhilosophyPage = lazy(() => import("./PhilosophyPage"))
const AboutPage = lazy(() => import("./AboutPage"))
const EcoTipsPage = lazy(() => import("./EcoTipsPage"))
const ConsultPage = lazy(() => import("./ConsultPage"))
const ProblemStatementPage = lazy(() => import("./ProblemStatementPage"))
const SustainableKitPage = lazy(() => import("./SustainableKitPage"))
const VendorsComingSoonPage = lazy(() => import("./VendorsComingSoonPage"))

const LoadingSpinner = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="flex flex-col items-center space-y-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      <p className="text-muted-foreground">Loading...</p>
    </div>
  </div>
)

export default function ClientRouter() {
  const [currentView, setCurrentView] = useState<
    | "home"
    | "solutions"
    | "events"
    | "ecotips"
    | "about"
    | "consult"
    | "vendors"
    | "login"
    | "problem-statement"
    | "sustainable-kit"
    | "vendors-coming-soon"
  >("home")

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const view = urlParams.get("view")
    if (
      view &&
      [
        "solutions",
        "events",
        "ecotips",
        "about",
        "consult",
        "vendors",
        "problem-statement",
        "sustainable-kit",
        "vendors-coming-soon",
      ].includes(view)
    ) {
      setCurrentView(view as typeof currentView)
    }
  }, [])

  useEffect(() => {
    const handleNavigation = (view: typeof currentView) => {
      setCurrentView(view)
      const url = view === "home" ? "/" : `/?view=${view}`
      window.history.pushState({}, "", url)
      window.scrollTo({ top: 0, behavior: "smooth" })
    }

    // Make navigation function globally available
    ;(window as any).navigateTo = handleNavigation
  }, [])

  return (
    <Suspense fallback={<LoadingSpinner />}>
      {currentView === "home" && <HomePage />}

      {currentView === "solutions" && <PhilosophyPage />}

      {currentView === "events" && (
        <EventPlanningFlow
          onBackToHome={() => setCurrentView("home")}
          onBack={() => setCurrentView("home")}
          onComplete={() => setCurrentView("home")}
        />
      )}

      {currentView === "vendors" && <VendorsPage onBack={() => setCurrentView("home")} />}

      {currentView === "ecotips" && <EcoTipsPage />}

      {currentView === "about" && <AboutPage />}

      {currentView === "consult" && <ConsultPage />}

      {currentView === "problem-statement" && <ProblemStatementPage />}

      {currentView === "login" && (
        <div className="container mx-auto px-4 py-16">
          <h1 className="text-4xl font-bold text-center mb-8">Login</h1>
          <p className="text-center text-muted-foreground">Login functionality coming soon!</p>
        </div>
      )}

      {currentView === "sustainable-kit" && (
        <SustainableKitPage
          onBack={() => setCurrentView("home")}
          onVendorsClick={() => setCurrentView("vendors-coming-soon")}
        />
      )}

      {currentView === "vendors-coming-soon" && (
        <VendorsComingSoonPage onBack={() => setCurrentView("sustainable-kit")} />
      )}
    </Suspense>
  )
}
