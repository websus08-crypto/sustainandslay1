"use client"

import { useState, useEffect } from "react"
import { Button } from "./ui/button"
import { ChevronRight, ArrowRight } from "lucide-react"

interface ProblemStatementsProps {
  onComplete: () => void
}

interface Slide {
  id: number
  text: string
  caption?: string
  background: string
  textColor: string
  buttonText: string
}

const slides: Slide[] = [
  {
    id: 1,
    text: "Let's turn celebration into conservation.",
    background: "bg-[#F5F1E8]", // Using exact beige color from images
    textColor: "text-[#4A4A4A]", // Using exact dark gray from images
    buttonText: "Let's go",
  },
  {
    id: 2,
    text: "Stunning decor today shouldn't mean landfill tomorrow.",
    background: "bg-[#6B8E5A]", // Using exact green color from images
    textColor: "text-white", // Using pure white for better contrast
    buttonText: "I agree",
  },
  {
    id: 3,
    text: "You can host a slay-worthy event without trashing the planet.",
    background: "bg-[#C17B5A]", // Using exact terracotta color from images
    textColor: "text-white", // Using pure white for better contrast
    buttonText: "Show me how",
  },
  {
    id: 4,
    text: "Let's turn celebration into conservation.",
    background: "bg-[#F5F1E8]", // Using exact beige color from images
    textColor: "text-[#4A4A4A]", // Using exact dark gray from images
    buttonText: "Let's go",
  },
]

export function ProblemStatements({ onComplete }: ProblemStatementsProps) {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)

  const nextSlide = () => {
    if (currentSlide === slides.length - 1) {
      onComplete()
      return
    }

    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentSlide((prev) => prev + 1)
      setIsTransitioning(false)
    }, 200)
  }

  const skipToSite = () => {
    onComplete()
  }

  // Auto-advance after 8 seconds if no interaction
  useEffect(() => {
    const timer = setTimeout(() => {
      if (currentSlide < slides.length - 1) {
        nextSlide()
      }
    }, 8000)

    return () => clearTimeout(timer)
  }, [currentSlide])

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " " || e.key === "ArrowRight") {
        e.preventDefault()
        nextSlide()
      }
      if (e.key === "Escape") {
        onComplete()
      }
    }

    window.addEventListener("keydown", handleKeyPress)
    return () => window.removeEventListener("keydown", handleKeyPress)
  }, [currentSlide])

  const current = slides[currentSlide]

  return (
    <div
      className={`fixed inset-0 flex items-center justify-center transition-colors duration-500 ${current.background}`}
    >
      {/* Skip button */}
      <Button
        variant="ghost"
        size="sm"
        onClick={skipToSite}
        className={`absolute top-6 right-6 ${current.textColor} hover:opacity-70 transition-opacity`}
      >
        Skip to site
      </Button>

      {/* Main content */}
      <div
        className={`max-w-5xl mx-auto px-8 text-center transition-all duration-300 ${
          isTransitioning ? "opacity-0 transform translate-y-4" : "opacity-100 transform translate-y-0"
        }`}
      >
        <h1 className={`text-5xl md:text-7xl font-bold leading-tight mb-12 ${current.textColor}`}>{current.text}</h1>

        {current.caption && <p className={`text-xl mb-12 ${current.textColor} opacity-80`}>{current.caption}</p>}

        <Button
          onClick={nextSlide}
          size="lg"
          className={`
            text-lg px-10 py-4 rounded-full font-medium transition-all duration-200 transform hover:scale-105
            ${
              current.background === "bg-[#F5F1E8]"
                ? "bg-[#6B8E5A] text-white hover:bg-[#5A7A4A]"
                : "bg-[#F5F1E8] text-[#4A4A4A] hover:bg-[#E8E4DB]"
            }
          `}
        >
          {current.buttonText}
          {currentSlide === slides.length - 1 ? (
            <ArrowRight className="ml-2 h-5 w-5" />
          ) : (
            <ChevronRight className="ml-2 h-5 w-5" />
          )}
        </Button>
      </div>

      {/* Progress indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div className="flex space-x-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setCurrentSlide(index)
              }}
              className={`
                w-3 h-3 rounded-full transition-all duration-200
                ${index === currentSlide ? `${current.textColor} opacity-100` : `${current.textColor} opacity-40`}
              `}
              style={{
                backgroundColor: index === currentSlide ? "currentColor" : "transparent",
                border: `2px solid currentColor`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Swipe hint for mobile */}
      <div
        className={`absolute bottom-20 left-1/2 transform -translate-x-1/2 md:hidden ${current.textColor} opacity-60`}
      >
        <p className="text-sm">Tap or swipe to continue</p>
      </div>
    </div>
  )
}
