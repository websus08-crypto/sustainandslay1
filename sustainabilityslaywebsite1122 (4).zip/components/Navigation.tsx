"use client"

import { useState } from "react"
import { Button } from "./ui/button"
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet"
import { Menu } from "lucide-react"
import Image from "next/image"

function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  const handleNavigation = (view?: string) => {
    if (view) {
      window.location.href = `/?view=${view}`
    } else {
      window.location.href = "/"
    }
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const navLinks = [
    { onClick: () => handleNavigation(), label: "Home" },
    { onClick: () => handleNavigation("about"), label: "About" },
    { onClick: () => handleNavigation("problem-statement"), label: "Problem Statement" },
    { onClick: () => handleNavigation("solutions"), label: "Philosophy & Solutions" },
    { onClick: () => handleNavigation("events"), label: "Events" },
    { onClick: () => handleNavigation("sustainable-kit"), label: "Sustainable Kit" },
    { onClick: () => handleNavigation("consult"), label: "Consult" },
    { onClick: () => handleNavigation("ecotips"), label: "EcoTips" },
  ]

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/30 bg-background/90 backdrop-blur-xl supports-[backdrop-filter]:bg-background/80 shadow-sm">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={() => handleNavigation()}
              className="flex items-center transition-transform duration-300 hover:scale-105 group"
            >
              <Image
                src="/sustain-slay-logo.png"
                alt="Sustain & Slay Logo"
                width={240}
                height={240}
                className="object-contain group-hover:scale-110 transition-transform duration-300 w-full h-44"
              />
            </button>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:block">
            <div className="ml-8 flex items-baseline space-x-6 xl:space-x-8">
              {navLinks.map((link, index) => (
                <button
                  key={index}
                  onClick={link.onClick}
                  className="font-body text-base font-medium text-stone hover:text-primary transition-all duration-300 hover:scale-105 relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          <div className="hidden lg:flex items-center ml-6">
            <Button onClick={() => handleNavigation("events")} className="btn-primary font-body text-base">
              Plan an Event
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:bg-accent/20">
                  <Menu className="h-6 w-6 text-primary" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="w-full sm:w-80 bg-background/95 backdrop-blur-xl border-l border-border/30"
              >
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between mb-12">
                    <div className="flex items-center">
                      <Image
                        src="/sustain-slay-logo.png"
                        alt="Sustain & Slay Logo"
                        width={200}
                        height={200}
                        className="h-24 w-auto object-contain"
                      />
                    </div>
                  </div>

                  {/* Mobile Navigation Links */}
                  <div className="flex flex-col space-y-6 mb-12">
                    {navLinks.map((link, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          link.onClick?.()
                          setIsOpen(false)
                        }}
                        className="font-body text-lg font-medium text-stone hover:text-primary transition-all duration-300 text-left py-2 px-4 rounded-lg hover:bg-accent/10"
                      >
                        {link.label}
                      </button>
                    ))}
                  </div>

                  <div className="mt-auto">
                    <Button
                      className="btn-primary w-full font-body text-base"
                      onClick={() => {
                        handleNavigation("events")
                        setIsOpen(false)
                      }}
                    >
                      Plan an Event
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  )
}

export { Navigation }
export default Navigation
