"use client"

import type React from "react"
import { useState } from "react"

import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Separator } from "./ui/separator"
import { Instagram, Mail, Check, AlertCircle } from "lucide-react"
import Image from "next/image"

export function Footer() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  const handleNavigation = (view?: string) => {
    if (view) {
      window.location.href = `/?view=${view}`
    } else {
      window.location.href = "/"
    }
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const footerLinks = {
    "About & Learn": [
      { label: "About", onClick: () => handleNavigation("about") },
      { label: "Contact", href: "mailto:sustainandslay08@gmail.com", target: "_blank", rel: "noopener noreferrer" },
      { label: "EcoTips", onClick: () => handleNavigation("ecotips") },
      { label: "Problem Statement", onClick: () => handleNavigation("problem-statement") },
    ],
    Services: [
      { label: "Event Planning", onClick: () => handleNavigation("events") },
      { label: "Vendor Network", onClick: () => handleNavigation("vendors") },
      { label: "Consult", onClick: () => handleNavigation("consult") },
      { label: "Sustainable Kit", onClick: () => handleNavigation("sustainable-kit") },
    ],
  }

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email.trim()) return

    setIsSubmitting(true)
    setMessage(null)

    try {
      const response = await fetch("/api/subscribe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: email.trim() }),
      })

      const data = await response.json()

      if (response.ok) {
        setMessage({ type: "success", text: data.message })
        setEmail("")
      } else {
        setMessage({ type: "error", text: data.error })
      }
    } catch (error) {
      setMessage({ type: "error", text: "Something went wrong. Please try again." })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <footer className="bg-muted/30 border-t">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Brand Section - Reduced width */}
            <div className="md:col-span-2 space-y-4">
              <div className="flex items-center group">
                <div className="relative">
                  <Image
                    src="/sustain-slay-logo.png"
                    alt="Sustain & Slay Logo"
                    width={140}
                    height={140}
                    className="object-contain group-hover:scale-105 transition-transform duration-300 w-full h-32"
                  />
                </div>
              </div>

              <p className="text-muted-foreground text-sm leading-relaxed max-w-md">
                Making events stylish, sustainable, and guilt‑free. Plan beautiful celebrations that honor both your
                vision and the planet.
              </p>

              {/* Newsletter Signup - More compact */}
              <div className="space-y-2">
                <h3 className="font-medium text-sm">Stay Updated</h3>
                <form onSubmit={handleNewsletterSubmit} className="flex space-x-2 max-w-sm">
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    required
                    className="flex-1 text-sm"
                    disabled={isSubmitting}
                  />
                  <Button type="submit" size="sm" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    ) : (
                      <Mail className="h-4 w-4" />
                    )}
                  </Button>
                </form>

                {message && (
                  <div
                    className={`flex items-center space-x-1 text-xs ${
                      message.type === "success" ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {message.type === "success" ? <Check className="h-3 w-3" /> : <AlertCircle className="h-3 w-3" />}
                    <span>{message.text}</span>
                  </div>
                )}

                <p className="text-xs text-muted-foreground">
                  Get sustainable event tips and vendor updates. No spam, ever.
                </p>
              </div>
            </div>

            {/* Footer Links - More compact columns */}
            {Object.entries(footerLinks).map(([category, links]) => (
              <div key={category} className="space-y-3">
                <h3 className="font-medium text-sm">{category}</h3>
                <ul className="space-y-1.5">
                  {links.map((link) => (
                    <li key={link.label}>
                      {link.onClick ? (
                        <button
                          onClick={link.onClick}
                          className="text-sm text-muted-foreground hover:text-primary transition-colors"
                        >
                          {link.label}
                        </button>
                      ) : (
                        <a
                          href={link.href}
                          target={link.target}
                          rel={link.rel}
                          className="text-sm text-muted-foreground hover:text-primary transition-colors"
                        >
                          {link.label}
                        </a>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Bottom Footer */}
        <div className="py-4">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-2 md:space-y-0">
            <div className="text-sm text-muted-foreground">© 2025 Sustain & Slay. All rights reserved.</div>

            <div className="flex items-center space-x-6">
              <a
                href="https://www.instagram.com/sustain.and.slay?igsh=NnQya2JpbWhhZjVv"
                className="text-muted-foreground hover:text-primary transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Follow us on Instagram</span>
              </a>

              <a
                href="mailto:sustainandslay08@gmail.com"
                className="text-muted-foreground hover:text-primary transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Mail className="h-5 w-5" />
                <span className="sr-only">Email us</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
