-- Create emails table for newsletter signups
CREATE TABLE IF NOT EXISTS public.emails (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  source TEXT DEFAULT 'footer_signup'
);

-- Enable RLS for security
ALTER TABLE public.emails ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to insert emails (for newsletter signup)
-- But only allow reading/updating by authenticated users (if needed later)
CREATE POLICY "Allow public email signup" ON public.emails 
  FOR INSERT 
  WITH CHECK (true);

-- Create policy to prevent public reading of emails (privacy)
CREATE POLICY "Prevent public email reading" ON public.emails 
  FOR SELECT 
  USING (false);
