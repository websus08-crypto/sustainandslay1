import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email || !email.includes("@")) {
      return NextResponse.json({ error: "Please provide a valid email address" }, { status: 400 })
    }

    const supabase = await createClient()

    // Insert email into database
    const { data, error } = await supabase
      .from("emails")
      .insert([
        {
          email: email.toLowerCase().trim(),
          source: "footer_signup",
        },
      ])
      .select()

    if (error) {
      // Handle duplicate email error gracefully
      if (error.code === "23505") {
        return NextResponse.json({ error: "This email is already subscribed!" }, { status: 409 })
      }

      console.error("Supabase error:", error)
      return NextResponse.json({ error: "Failed to subscribe. Please try again." }, { status: 500 })
    }

    return NextResponse.json({ message: "Successfully subscribed to updates!" }, { status: 200 })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 })
  }
}
