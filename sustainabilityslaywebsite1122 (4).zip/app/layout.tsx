import type React from "react"
import type { Metadata } from "next"
import { Poppins, Lora } from "next/font/google"
import { Suspense } from "react"
import "./globals.css"

import { ClientLayout } from "../components/ClientLayout"

const poppins = Poppins({
  subsets: ["latin"],
  variable: "--font-poppins",
  weight: ["300", "400", "500", "600", "700"],
})

const lora = Lora({
  subsets: ["latin"],
  variable: "--font-lora",
  weight: ["400", "500", "600", "700"],
})

export const metadata: Metadata = {
  title: "Sustain & Slay - Sustainable Event Planning",
  description: "Plan beautiful, eco-friendly events that make a positive impact",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${poppins.variable} ${lora.variable} font-sans antialiased`}>
        <ClientLayout>
          <Suspense fallback={null}>{children}</Suspense>
        </ClientLayout>
      </body>
    </html>
  )
}
