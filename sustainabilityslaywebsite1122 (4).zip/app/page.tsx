import { Suspense } from "react"
import ClientRouter from "../components/ClientRouter"

const LoadingSpinner = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="flex flex-col items-center space-y-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      <p className="text-muted-foreground">Loading...</p>
    </div>
  </div>
)

export default function Page() {
  return (
    <div className="min-h-screen bg-background">
      <Suspense fallback={<LoadingSpinner />}>
        <ClientRouter />
      </Suspense>
    </div>
  )
}
