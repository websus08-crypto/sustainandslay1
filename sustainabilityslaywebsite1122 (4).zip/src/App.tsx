"use client"

import { useState } from "react"
import { Navigation } from "./components/Navigation"
import { ProblemStatements } from "./components/ProblemStatements"
import { HomePage } from "./components/HomePage"
import { EventPlanningFlow } from "./components/EventPlanningFlow"
import { Footer } from "./components/Footer"
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card"
import { Input } from "../components/ui/input"
import { Label } from "../components/ui/label"
import { Button } from "../components/ui/button"
import { Linkedin } from "lucide-react"

type AppState =
  | "problem-statements"
  | "home"
  | "event-planning"
  | "solutions"
  | "about"
  | "ecotips"
  | "consult"
  | "vendors"
  | "info"

export default function App() {
  const [currentView, setCurrentView] = useState<AppState>("problem-statements")
  const [selectedEventType, setSelectedEventType] = useState<string>()

  const handleProblemStatementsComplete = () => {
    setCurrentView("home")
  }

  const handlePlanEventClick = (eventType?: string) => {
    setSelectedEventType(eventType)
    setCurrentView("event-planning")
  }

  const handleEventPlanningComplete = () => {
    setCurrentView("home")
  }

  const handleEventPlanningBack = () => {
    setCurrentView("home")
  }

  const handleEcoTipsClick = () => {
    setCurrentView("ecotips")
  }

  const handleCalculatorClick = () => {
    setCurrentView("info")
  }

  const handleConsultClick = () => {
    setCurrentView("consult")
  }

  const handleLoginClick = () => {
    // In a real app, this would open a login modal or navigate to login page
    alert("Login functionality would be implemented here")
  }

  const handleSolutionsClick = () => {
    setCurrentView("solutions")
  }

  const handleAboutClick = () => {
    setCurrentView("about")
  }

  const handleVendorsClick = () => {
    setCurrentView("vendors")
  }

  const handleHomeClick = () => {
    setCurrentView("home")
  }

  // Render different views based on current state
  const renderCurrentView = () => {
    switch (currentView) {
      case "problem-statements":
        return <ProblemStatements onComplete={handleProblemStatementsComplete} />

      case "home":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />
            <HomePage
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
            />
            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      case "event-planning":
        return (
          <div className="min-h-screen bg-background">
            <Navigation
              onLoginClick={handleLoginClick}
              onPlanEventClick={() => handlePlanEventClick()}
              onHomeClick={handleHomeClick}
              onSolutionsClick={handleSolutionsClick}
              onEcoTipsClick={handleEcoTipsClick}
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onVendorsClick={handleVendorsClick}
            />
            <EventPlanningFlow
              onComplete={handleEventPlanningComplete}
              onBack={handleEventPlanningBack}
              eventType={selectedEventType}
            />
          </div>
        )

      case "solutions":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />

            {/* Hero Section */}
            <section className="py-20 bg-secondary">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
                <h1 className="text-h1 font-display font-semibold mb-6 text-balance">Philosophy & Solution</h1>
                <div className="max-w-2xl mx-auto space-y-4 text-lg text-muted-foreground">
                  <p>You care about the environment.</p>
                  <p>You've heard about climate change.</p>
                  <p>You feel the urgency, but let's be honest... planning a celebration is already enough stress.</p>
                  <p className="text-xl font-medium text-primary italic">
                    "How can I make it eco-friendly without losing the magic?"
                  </p>
                  <p>That's the question we kept hearing, and it's exactly why we created this platform.</p>
                </div>
              </div>
            </section>

            {/* Mission Section */}
            <section className="py-20 bg-background">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                  <h2 className="text-h2 font-display font-semibold mb-6 text-primary">
                    💚 The Idea That Sparked a Movement
                  </h2>
                  <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                    A bunch of curious, climate-conscious dreamers (that's us!) came together and asked:
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                  <Card className="border-0 shadow-lg bg-card/50">
                    <CardContent className="p-8 text-center">
                      <h3 className="font-semibold text-lg mb-4">
                        What if events could be joyful and planet-positive at the same time?
                      </h3>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg bg-card/50">
                    <CardContent className="p-8 text-center">
                      <h3 className="font-semibold text-lg mb-4">What if weddings didn't leave behind waste?</h3>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg bg-card/50">
                    <CardContent className="p-8 text-center">
                      <h3 className="font-semibold text-lg mb-4">
                        What if birthdays felt just as grand, but with a lighter footprint?
                      </h3>
                    </CardContent>
                  </Card>
                  <Card className="border-0 shadow-lg bg-card/50">
                    <CardContent className="p-8 text-center">
                      <h3 className="font-semibold text-lg mb-4">
                        What if you could throw the party of your dreams and feel proud of the impact you made?
                      </h3>
                    </CardContent>
                  </Card>
                </div>

                <div className="text-center">
                  <p className="text-lg text-muted-foreground">
                    So we built the first-of-its-kind platform that makes planning an eco-conscious event easy,
                    exciting, and entirely yours.
                  </p>
                </div>
              </div>
            </section>

            {/* How It Works Section */}
            <section className="py-20 bg-muted/20">
              <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-16">
                  <h2 className="text-h2 font-display font-semibold mb-6 text-primary">How It Works:</h2>
                </div>

                <div className="space-y-12">
                  {/* Step 1 */}
                  <div className="flex flex-col lg:flex-row items-center gap-8">
                    <div className="lg:w-1/3">
                      <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-xl mb-4">
                        1
                      </div>
                    </div>
                    <div className="lg:w-2/3">
                      <h3 className="text-xl font-semibold mb-4 text-primary">Tell Us About Your Event</h3>
                      <p className="text-muted-foreground">
                        Planning a wedding? A birthday? A work retreat? Just choose your event type, budget, and guest
                        count. That's it.
                      </p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex flex-col lg:flex-row-reverse items-center gap-8">
                    <div className="lg:w-1/3">
                      <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground font-bold text-xl mb-4">
                        2
                      </div>
                    </div>
                    <div className="lg:w-2/3">
                      <h3 className="text-xl font-semibold mb-4 text-primary">Explore Green-Ready Vendors</h3>
                      <p className="text-muted-foreground">
                        We've got a curated list of amazing vendors - caterers, venues, decorators, photographers who
                        are already eco-friendly or open to becoming one for you. You'll see what sustainable practices
                        they offer and how they fit your budget.
                      </p>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex flex-col lg:flex-row items-center gap-8">
                    <div className="lg:w-1/3">
                      <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center text-accent-foreground font-bold text-xl mb-4">
                        3
                      </div>
                    </div>
                    <div className="lg:w-2/3">
                      <h3 className="text-xl font-semibold mb-4 text-primary">Mix, Match & Customise Your Impact</h3>
                      <p className="text-muted-foreground">
                        Like the idea of local flowers? Digital invites? Reusable cutlery? Add it to your cart, tweak
                        it, explore combinations — and we'll show you how much waste, water, and carbon you'll save by
                        making just a few small swaps.
                      </p>
                    </div>
                  </div>

                  {/* Step 4 */}
                  <div className="flex flex-col lg:flex-row-reverse items-center gap-8">
                    <div className="lg:w-1/3">
                      <div className="w-16 h-16 bg-primary/80 rounded-full flex items-center justify-center text-primary-foreground font-bold text-xl mb-4">
                        4
                      </div>
                    </div>
                    <div className="lg:w-2/3">
                      <h3 className="text-xl font-semibold mb-4 text-primary">
                        Can't Go Fully Green? You Still Make a Difference.
                      </h3>
                      <p className="text-muted-foreground mb-4">
                        Not everything may work out — and that's okay. You can still give back by:
                      </p>
                      <ul className="space-y-2 text-muted-foreground">
                        <li className="flex items-center gap-2">
                          <span>🌳</span> Donating to tree plantations
                        </li>
                        <li className="flex items-center gap-2">
                          <span>🍲</span> Supporting food donation or composting
                        </li>
                        <li className="flex items-center gap-2">
                          <span>♻️</span> Contributing to local recycling initiatives
                        </li>
                      </ul>
                      <p className="text-muted-foreground mt-4 font-medium">Even one small step makes an impact.</p>
                    </div>
                  </div>

                  {/* Step 5 */}
                  <div className="flex flex-col lg:flex-row items-center gap-8">
                    <div className="lg:w-1/3">
                      <div className="w-16 h-16 bg-secondary/80 rounded-full flex items-center justify-center text-secondary-foreground font-bold text-xl mb-4">
                        5
                      </div>
                    </div>
                    <div className="lg:w-2/3">
                      <h3 className="text-xl font-semibold mb-4 text-primary">
                        Celebrate Consciously - and Get a Badge of Honour
                      </h3>
                      <p className="text-muted-foreground">
                        After your event, you'll receive a beautiful Eco Impact Certificate showing how your choices
                        helped the planet. It's something to be proud of and to inspire others.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Closing Section */}
            <section className="py-20 bg-primary">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-h2 font-display font-semibold mb-8 text-primary-foreground">
                  A New Kind of Celebration Starts Here
                </h2>

                <div className="space-y-6 text-primary-foreground/90 text-lg max-w-2xl mx-auto">
                  <p>This isn't just about planning an event.</p>
                  <p>This is about starting a ripple - one conscious choice at a time.</p>
                  <p>It's about redefining what a celebration can mean.</p>

                  <div className="py-8">
                    <p className="text-xl font-semibold text-primary-foreground">Not less, but more:</p>
                    <div className="mt-4 space-y-2">
                      <p>More intentional. More soulful. More beautiful.</p>
                    </div>
                  </div>

                  <p className="text-xl font-medium text-primary-foreground">
                    Because joy shouldn't come at the planet's expense — and now, it doesn't have to.
                  </p>
                </div>

                <div className="mt-12">
                  <Button
                    onClick={() => setCurrentView("consult")}
                    size="lg"
                    className="px-8 py-4 bg-primary-foreground text-primary font-medium rounded-xl hover:bg-primary-foreground/90 transition-colors"
                  >
                    Start Your Sustainable Event Journey
                  </Button>
                </div>
              </div>
            </section>

            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      case "about":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />
            <div className="py-20">
              <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
                {/* Hero Section */}
                <div className="text-center mb-16">
                  <h1 className="text-h1 font-display font-semibold mb-8 text-primary">About Sustain & Slay</h1>
                  <div className="max-w-4xl mx-auto">
                    <p className="text-lg text-foreground leading-relaxed mb-6">
                      We're the kind of people who notice the food waste at weddings more than the food itself.
                    </p>
                    <p className="text-lg text-foreground leading-relaxed mb-6">
                      A bunch of curious, climate-conscious dreamers (that's us!) came together and asked: What if
                      events could be fun and planet-positive at the same time?
                    </p>
                    <p className="text-lg text-foreground leading-relaxed mb-6">
                      We're a bunch of celebration-lovers and climate worriers who decided to do something about the
                      chaos and the carbon. We love a good mehendi playlist, OTT decor, and those late-night dance
                      parties but not at the cost of overflowing landfills or single-use anything.
                    </p>
                    <p className="text-lg text-foreground leading-relaxed mb-6">
                      Believing in the power of action and the art of rewriting narratives, we launched this platform to
                      reimagine event planning a one-stop destination for discovering and hosting sustainable weddings,
                      parties, and joyful gatherings across India. From eco-friendly vendors to plastic-free party tips,
                      we're making it easy (and sexy) to party with a conscience.
                    </p>
                    <p className="text-lg text-foreground leading-relaxed mb-6">
                      For us, thoughtful celebrations go beyond perfection; they are about creativity, genuine
                      connections, and ensuring every gathering is a little gentler on the planet. After all, the best
                      celebrations aren't just the ones that feel good but the ones that do good long after the music
                      fades.
                    </p>
                    <p className="text-lg text-foreground leading-relaxed mb-6">
                      This platform invites everyone to craft events that reflect their values and inspire others -
                      without any guilt trips or feelings of helplessness.
                    </p>
                    <p className="text-lg text-primary font-medium leading-relaxed mb-8">
                      If you're the kind of person who wants your celebration to reflect your values (without giving up
                      on the gulab jamuns or good times), welcome. We're here for the mindful misfits, the climate
                      romantics, and the people who believe the Earth deserves an invite too.
                    </p>
                    <p className="text-xl font-semibold text-accent">
                      Let's make sustainability easy, simple, fun and memorable!
                    </p>
                  </div>
                </div>

                {/* Team Section */}
                <div className="mb-16">
                  <h2 className="text-h2 font-display font-semibold text-center mb-12 text-primary">Meet Our Team</h2>

                  <div className="grid grid-cols-1 gap-16 max-w-2xl mx-auto">
                    {/* Alisha */}
                    <div className="text-center">
                      <div className="mb-6">
                        <img
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Alisha.jpg-cVUfdtYJ5OvxGsell1mageokHjPYVq.jpeg"
                          alt="Alisha"
                          className="w-48 h-48 rounded-full mx-auto object-cover shadow-lg"
                        />
                      </div>
                      <div className="flex items-center justify-center gap-3 mb-4">
                        <h3 className="text-h3 font-display font-semibold text-primary">Alisha</h3>
                        <a
                          href="#"
                          className="text-accent hover:text-primary transition-colors"
                          aria-label="Alisha's LinkedIn"
                        >
                          <Linkedin className="w-5 h-5" />
                        </a>
                      </div>
                      <p className="text-foreground leading-relaxed">
                        I am curious about the inspiring stories people bring to every gathering. A policy analyst by
                        profession and a climate optimist at heart, I hold a Master's in Public Policy from King's
                        College London. Over the years, I have collaborated with the education ministries of Delhi and
                        Maharashtra, played a key role in digitising education systems, and led India's largest
                        mentoring initiative, Desh Ke Mentor.
                      </p>
                    </div>

                    {/* Mehar */}
                    <div className="text-center">
                      <div className="mb-6">
                        <img
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mehar.jpg-QWrAoj57e0AzK7oY0dWNw192nO7QxV.jpeg"
                          alt="Mehar"
                          className="w-48 h-48 rounded-full mx-auto object-cover shadow-lg"
                        />
                      </div>
                      <div className="flex items-center justify-center gap-3 mb-4">
                        <h3 className="text-h3 font-display font-semibold text-primary">Mehar</h3>
                        <a
                          href="#"
                          className="text-accent hover:text-primary transition-colors"
                          aria-label="Mehar's LinkedIn"
                        >
                          <Linkedin className="w-5 h-5" />
                        </a>
                      </div>
                      <p className="text-foreground leading-relaxed">
                        Over the past five years, I've explored the many layers of climate action - from the technical
                        and institutional to the cultural and ecological. My work spans public transport, urban
                        planning, emissions trading, and waste management, as well as wetlands, ecosystem conservation,
                        and indigenous practices. Having studied Political Science from the University of Delhi and
                        Public Policy from King's College London, I approach climate issues through a systemic lens. I
                        believe that long-term change doesn't emerge from a single sector or solution, but through the
                        careful interlinking of diverse voices and visions.
                      </p>
                    </div>

                    {/* Yukta */}
                    <div className="text-center">
                      <div className="mb-6">
                        <img
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/yukta-kPCc90MhdY8hovgMCVNUC1Y5Z0h93L.jpeg"
                          alt="Yukta"
                          className="w-48 h-48 rounded-full mx-auto object-cover shadow-lg"
                        />
                      </div>
                      <div className="flex items-center justify-center gap-3 mb-4">
                        <h3 className="text-h3 font-display font-semibold text-primary">Yukta</h3>
                        <a
                          href="#"
                          className="text-accent hover:text-primary transition-colors"
                          aria-label="Yukta's LinkedIn"
                        >
                          <Linkedin className="w-5 h-5" />
                        </a>
                      </div>
                      <p className="text-foreground leading-relaxed">
                        I'm Yukta, a University of Delhi grad who loves exploring the sweet spot where tech, climate,
                        and community meet. My journey has taken me from researching ethical AI to working on grassroots
                        climate action and health initiatives, all tied together by one belief: small choices can spark
                        big change. I believe sustainability isn't about perfection. It's about creativity, balance, and
                        joy in the process. Conscious living should feel empowering, not exhausting.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Call to Action */}
                <div className="text-center">
                  <Button
                    onClick={() => setCurrentView("consult")}
                    className="bg-primary hover:bg-primary/90 text-white px-8 py-3 text-lg"
                  >
                    Work With Us
                  </Button>
                </div>
              </div>
            </div>
            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      case "ecotips":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />

            {/* Hero Section */}
            <section className="py-20 bg-secondary">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
                <h1 className="text-h1 font-display font-semibold mb-6">EcoTips</h1>
                <p className="text-lg text-muted-foreground">
                  Discover sustainable celebration ideas, tips, and inspiration for planet-positive events.
                </p>
              </div>
            </section>

            {/* Featured Blog Post */}
            <section className="py-20 bg-background">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
                <article className="prose prose-lg max-w-none">
                  <header className="mb-12 text-center">
                    <h2 className="text-h2 font-display font-semibold mb-4 text-primary text-balance">
                      The Celebration That Lasts Longer Than a Night...
                    </h2>
                    <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                      <span>Featured Article</span>
                      <span>•</span>
                      <span>Sustainable Celebrations</span>
                    </div>
                  </header>

                  <div className="space-y-8 text-foreground leading-relaxed">
                    <p className="text-lg">
                      Making memories is India's favourite language: cousins tumbling out of dawn trains, aunties
                      debating the perfect laddoo, the dhol shaking the street awake until neighbours gather at the gate
                      with smiles. Here, joy is not once-a-year, it is all year, stitched into calendars, shared like
                      prasad, open to everyone who passes by.
                    </p>

                    <p>
                      But once the lights dim and playlists fade, another scene unfolds: sacks of plastic plates,
                      mountains of wilting flowers, heaps of half-eaten food, and trucks packed with mixed waste. A
                      typical wedding of a few hundred guests can generate 2–3 tonnes of waste across just three days.
                      That's not "just a party", that's a small city's footprint, created overnight.
                    </p>

                    <p>
                      India's Solid Waste Management Rules already recognise this reality. Any event producing more than
                      100 kg of waste a day is legally a bulk waste generator, expected to segregate and responsibly
                      process its waste. In other words, weddings and festivals aren't small, private affairs anymore;
                      they operate at industrial scale whether we realise it or not.
                    </p>

                    <p className="text-xl font-medium text-primary italic text-center py-4">
                      And yet, the answer isn't to shrink our joy. It's to choose joy that lasts longer than a single
                      evening.
                    </p>

                    <div className="bg-secondary/50 rounded-lg p-8 my-12">
                      <h3 className="text-xl font-semibold mb-6 text-primary">Reusables: Our Forgotten Tradition</h3>

                      <p className="mb-6">
                        Our own history shows us the way. For generations, India's celebrations were naturally
                        low-waste:
                      </p>

                      <div className="space-y-4 mb-6">
                        <p>
                          South Indian weddings served feasts on banana leaves, folded neatly back into the soil as
                          compost the next morning. Steel tumblers of water circled endlessly, and nothing was "use and
                          throw."
                        </p>

                        <p>
                          Village festivals used clay diyas, handmade rangolis, brass lamps, and fabric pandals stitched
                          from cotton sheets—items that lived many lives, not just one.
                        </p>
                      </div>

                      <p className="font-medium">
                        None of this felt like compromise—it felt abundant, welcoming, rooted. Guests ate, laughed, and
                        remembered the event not for its disposables, but for its warmth.
                      </p>
                    </div>

                    <p className="text-lg font-medium text-primary">
                      Switching from single-use to reusable is not a burden; it's a return to our roots with a modern
                      shine.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-12">
                      <Card className="border-0 shadow-lg">
                        <CardContent className="p-6">
                          <h4 className="font-semibold mb-3 text-primary">Cutlery & Plates</h4>
                          <p className="text-sm">
                            Renting steel or glassware eliminates waste and elevates dining. Guests eat comfortably,
                            servers move easily, and not a single trash bag fills with soggy disposables.
                          </p>
                        </CardContent>
                      </Card>

                      <Card className="border-0 shadow-lg">
                        <CardContent className="p-6">
                          <h4 className="font-semibold mb-3 text-primary">Décor</h4>
                          <p className="text-sm">
                            Fabric drapes, brass lamps, terracotta pots, and live plants look richer than plastic and
                            can be reused across years of celebrations.
                          </p>
                        </CardContent>
                      </Card>

                      <Card className="border-0 shadow-lg">
                        <CardContent className="p-6">
                          <h4 className="font-semibold mb-3 text-primary">Serving & Storage</h4>
                          <p className="text-sm">
                            Steel tumblers, water dispensers, and durable trays make hydration and food service cleaner
                            and cheaper in the long run.
                          </p>
                        </CardContent>
                      </Card>

                      <Card className="border-0 shadow-lg">
                        <CardContent className="p-6">
                          <h4 className="font-semibold mb-3 text-primary">Flowers & Rituals</h4>
                          <p className="text-sm">
                            Marigolds, mango leaves, and clay can be composted or reused in rituals the next day instead
                            of choking drains.
                          </p>
                        </CardContent>
                      </Card>
                    </div>

                    <p>
                      In India, celebration has always been about showing care for your guests. Today, that care extends
                      beyond what's served on the plate; it includes what happens to the plate itself. A host who
                      chooses reusable cutlery, compostable décor, and pooled transport isn't just throwing a party.
                      They're setting a new standard of hospitality: joy without harm.
                    </p>

                    <div className="bg-primary/10 rounded-lg p-8 my-12 text-center">
                      <h3 className="text-xl font-semibold mb-4 text-primary">
                        At Sustain & Slay, together we can design events that breathe!
                      </h3>

                      <div className="text-left max-w-2xl mx-auto">
                        <p className="mb-4 font-medium">The formula can be simple:</p>
                        <ul className="space-y-2 text-sm">
                          <li>• Design for reusables first: steel, glass, cloth, and clay.</li>
                          <li>
                            • Compostables only where composting is real: banana leaves, flowers, paper that's actually
                            collected.
                          </li>
                          <li>• Confirm segregation and processing before the invitations go out.</li>
                          <li>• Right-size menus and lock in donations for surplus food.</li>
                          <li>• Cut kilometres, not guests: choose closer venues and shared transport.</li>
                        </ul>
                      </div>
                    </div>

                    <p>
                      When we do this, a celebration stops being a bulk waste event and becomes a living memory: the
                      music fades, the joy lingers, and the ground looks as if it were respected, not used up.
                    </p>

                    <p className="text-lg font-medium text-center py-6 text-primary">
                      Because in the end, what guests remember is not the pile of plates behind the tent, but the warmth
                      of being welcomed. Let our gatherings be abundant in joy, generous in care, and light in their
                      footprint, so the memories outlast the waste.
                    </p>
                  </div>
                </article>

                {/* Call to Action */}
                <div className="mt-16 text-center">
                  <div className="bg-secondary rounded-lg p-8">
                    <h3 className="text-xl font-semibold mb-4 text-primary">
                      Ready to plan your sustainable celebration?
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      Let us help you create an event that's abundant in joy and light in its footprint.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <Button
                        onClick={() => setCurrentView("event-planning")}
                        className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
                      >
                        Plan Your Event
                      </Button>
                      <Button
                        onClick={() => setCurrentView("consult")}
                        variant="outline"
                        className="px-6 py-3 border-primary text-primary rounded-lg hover:bg-primary/10"
                      >
                        Get Consultation
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      case "consult":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />
            <section className="py-20 bg-muted/20">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                  <h1 className="text-h1 font-display font-semibold mb-6 text-balance">
                    Enquire about our services or ask us about our sustainability consulting, and we'll get back to you
                    shortly!
                  </h1>
                  <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8">
                    **WE DO NOT SHARE DATA WITH ANY THIRD PARTIES.**
                  </div>
                </div>

                <Card className="border-0 shadow-xl bg-background/90 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="text-primary font-medium">Contact Us</CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <form className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-primary font-medium">
                            Your name *
                          </Label>
                          <Input
                            id="name"
                            type="text"
                            placeholder="Name"
                            required
                            className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="email" className="text-primary font-medium">
                            Email *
                          </Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="name@example.com"
                            required
                            className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="location" className="text-primary font-medium">
                            Location *
                          </Label>
                          <Input
                            id="location"
                            type="text"
                            placeholder="Which city?"
                            required
                            className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="phone" className="text-primary font-medium">
                            Phone *
                          </Label>
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="Enter your phone number"
                            required
                            className="h-12 rounded-xl border-2 border-border focus:border-primary transition-colors"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="enquiry-type" className="text-primary font-medium">
                            Enquiring about *
                          </Label>
                          <select
                            id="enquiry-type"
                            required
                            className="h-12 w-full rounded-xl border-2 border-border focus:border-primary transition-colors bg-background px-3 text-foreground"
                          >
                            <option value="">Choose an option</option>
                            <option value="event-planning">Full Event Planning</option>
                            <option value="sustainability-consulting">Sustainability Consulting</option>
                            <option value="vendor-network">Vendor Network Access</option>
                            <option value="impact-assessment">Event Impact Assessment</option>
                            <option value="corporate-events">Corporate Event Services</option>
                            <option value="wedding-planning">Sustainable Wedding Planning</option>
                            <option value="other">Other Services</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="message" className="text-primary font-medium">
                            Your message *
                          </Label>
                          <textarea
                            id="message"
                            placeholder="I need Sustain & Slay's help for..."
                            required
                            rows={4}
                            className="w-full rounded-xl border-2 border-border focus:border-primary transition-colors bg-background px-3 py-3 text-foreground resize-none"
                          />
                        </div>
                      </div>

                      <div className="pt-6">
                        <Button
                          type="submit"
                          size="lg"
                          className="w-full md:w-auto px-12 py-4 bg-secondary hover:bg-secondary/90 text-secondary-foreground rounded-xl font-medium text-lg"
                        >
                          Send Enquiry
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>

                {/* Additional Information Section */}
                <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
                  <Card className="border-0 shadow-lg text-center">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Quick Response</h3>
                      <p className="text-sm text-muted-foreground">
                        We typically respond within 24 hours to all consultation requests.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg text-center">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M9 12l2 2 4-4m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Free Consultation</h3>
                      <p className="text-sm text-muted-foreground">
                        Initial consultations are complimentary to understand your sustainability goals.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg text-center">
                    <CardContent className="p-6">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Personalized Approach</h3>
                      <p className="text-sm text-muted-foreground">
                        Every event is unique. We tailor our services to your specific needs and values.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </section>
            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      case "vendors":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />

            {/* Hero Section */}
            <section className="bg-secondary py-24">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
                {/* Coming Soon Badge */}
                <div className="mb-6">
                  <span className="inline-flex items-center px-6 py-3 rounded-full font-medium bg-primary text-primary-foreground shadow-sm">
                    Coming Soon
                  </span>
                </div>

                <p className="text-sm text-muted-foreground mb-8 max-w-md mx-auto">
                  We're curating a list of eco-conscious vendors. Stay tuned.
                </p>

                <h1 className="text-h1 font-display mb-6">Eco-Friendly Vendors Directory</h1>

                <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                  Discover trusted partners who make your events sustainable and beautiful.
                </p>
              </div>
            </section>

            {/* Placeholder Vendor Directory Section */}
            <section className="py-20 bg-background">
              <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                  {/* Vendor Card 1 */}
                  <div className="relative bg-card rounded-lg border border-border shadow-sm overflow-hidden">
                    <div className="absolute inset-0 bg-muted/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <span className="font-medium text-muted-foreground">Coming Soon</span>
                    </div>
                    <div className="p-6 filter blur-sm">
                      <div className="w-12 h-12 bg-primary/20 rounded-full mb-4 flex items-center justify-center">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13m0-13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Green Catering Co.</h3>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent-foreground mb-3">
                        Catering
                      </span>
                      <p className="text-sm text-muted-foreground">
                        Farm-to-table organic catering with zero-waste packaging and locally sourced ingredients.
                      </p>
                    </div>
                  </div>

                  {/* Vendor Card 2 */}
                  <div className="relative bg-card rounded-lg border border-border shadow-sm overflow-hidden">
                    <div className="absolute inset-0 bg-muted/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <span className="font-medium text-muted-foreground">Coming Soon</span>
                    </div>
                    <div className="p-6 filter blur-sm">
                      <div className="w-12 h-12 bg-primary/20 rounded-full mb-4 flex items-center justify-center">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Eco Event Spaces</h3>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent-foreground mb-3">
                        Venues
                      </span>
                      <p className="text-sm text-muted-foreground">
                        LEED-certified venues with renewable energy and sustainable practices for memorable events.
                      </p>
                    </div>
                  </div>

                  {/* Vendor Card 3 */}
                  <div className="relative bg-card rounded-lg border border-border shadow-sm overflow-hidden">
                    <div className="absolute inset-0 bg-muted/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <span className="font-medium text-muted-foreground">Coming Soon</span>
                    </div>
                    <div className="p-6 filter blur-sm">
                      <div className="w-12 h-12 bg-primary/20 rounded-full mb-4 flex items-center justify-center">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v16a4 4 0 01-4 4zM21 5a2 2 0 00-2-2h-4a2 2 0 00-2 2v12a4 4 0 004 4 4 4 0 004-4V5z"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Bloom & Flourish</h3>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent-foreground mb-3">
                        Decorators
                      </span>
                      <p className="text-sm text-muted-foreground">
                        Sustainable floral arrangements and reusable decorations made from natural materials.
                      </p>
                    </div>
                  </div>

                  {/* Vendor Card 4 */}
                  <div className="relative bg-card rounded-lg border border-border shadow-sm overflow-hidden">
                    <div className="absolute inset-0 bg-muted/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <span className="font-medium text-muted-foreground">Coming Soon</span>
                    </div>
                    <div className="p-6 filter blur-sm">
                      <div className="w-12 h-12 bg-primary/20 rounded-full mb-4 flex items-center justify-center">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 10l12-3" />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Conscious Gifting</h3>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent-foreground mb-3">
                        Gifts
                      </span>
                      <p className="text-sm text-muted-foreground">
                        Ethical and meaningful gifts that support local artisans and environmental causes.
                      </p>
                    </div>
                  </div>

                  {/* Vendor Card 5 */}
                  <div className="relative bg-card rounded-lg border border-border shadow-sm overflow-hidden">
                    <div className="absolute inset-0 bg-muted/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <span className="font-medium text-muted-foreground">Coming Soon</span>
                    </div>
                    <div className="p-6 filter blur-sm">
                      <div className="w-12 h-12 bg-primary/20 rounded-full mb-4 flex items-center justify-center">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"
                          />
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Harmony Entertainment</h3>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent-foreground mb-3">
                        Entertainment
                      </span>
                      <p className="text-sm text-muted-foreground">
                        Local musicians and performers who support environmental and social causes.
                      </p>
                    </div>
                  </div>

                  {/* Vendor Card 6 */}
                  <div className="relative bg-card rounded-lg border border-border shadow-sm overflow-hidden">
                    <div className="absolute inset-0 bg-muted/50 backdrop-blur-sm z-10 flex items-center justify-center">
                      <span className="font-medium text-muted-foreground">Coming Soon</span>
                    </div>
                    <div className="p-6 filter blur-sm">
                      <div className="w-12 h-12 bg-primary/20 rounded-full mb-4 flex items-center justify-center">
                        <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"
                          />
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"
                          />
                        </svg>
                      </div>
                      <h3 className="font-semibold mb-2">Lens & Legacy</h3>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent-foreground mb-3">
                        Photography
                      </span>
                      <p className="text-sm text-muted-foreground">
                        Sustainable photography services with digital-first delivery and eco-friendly practices.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <p className="text-muted-foreground max-w-2xl mx-auto">
                    We are building a list of sustainable caterers, venues, decorators, and more for you. Our team is
                    carefully vetting each partner to ensure they meet our high standards for environmental
                    responsibility and quality.
                  </p>
                </div>
              </div>
            </section>

            {/* Stay Updated Section */}
            <section className="py-20 bg-secondary">
              <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-h2 font-display mb-4">Want to know when vendors go live?</h2>

                <p className="text-lg text-muted-foreground mb-8">
                  Sign up to be the first to access our curated vendor list.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto mb-6">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    className="flex-1 px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <Button className="px-6 py-3 bg-primary text-primary-foreground font-medium rounded-lg hover:bg-primary/90 transition-colors">
                    Notify Me
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground">
                  You'll be the first to know when our vendor directory launches.
                </p>
              </div>
            </section>

            {/* Call-to-Action Section */}
            <section className="py-20 bg-primary">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-h2 font-display text-primary-foreground mb-6">
                  In the meantime, explore how you can make your events planet-positive.
                </h2>

                <Button
                  onClick={() => setCurrentView("solutions")}
                  className="px-8 py-4 bg-primary-foreground text-primary font-medium rounded-lg hover:bg-primary-foreground/90 transition-colors"
                >
                  Explore Solutions
                </Button>
              </div>
            </section>

            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      case "info":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />
            <div className="py-20">
              <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
                <h1 className="text-h1 font-display font-semibold mb-6">Event Impact Calculator</h1>
                <p className="text-lg text-muted-foreground mb-8">
                  Coming soon - estimate your event's environmental impact and discover improvement opportunities.
                </p>
                <Button onClick={() => setCurrentView("home")} className="text-primary hover:underline">
                  ← Back to Home
                </Button>
              </div>
            </div>
            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      case "event-planning":
        return (
          <div>
            <Navigation
              onPlanEventClick={handlePlanEventClick}
              onEcoTipsClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
              onLoginClick={handleLoginClick}
              onSolutionsClick={handleSolutionsClick}
              onAboutClick={handleAboutClick}
              onVendorsClick={handleVendorsClick}
              onHomeClick={handleHomeClick}
            />
            <EventPlanningFlow
              onComplete={handleEventPlanningComplete}
              onBack={handleEventPlanningBack}
              eventType={selectedEventType}
            />
            <Footer
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onEcoTipsClick={handleEcoTipsClick}
              onVendorClick={handleVendorsClick}
              onCalculatorClick={handleCalculatorClick}
              onEventPlanningClick={() => handlePlanEventClick()}
            />
          </div>
        )

      default:
        return (
          <div className="min-h-screen bg-background">
            <Navigation
              onLoginClick={handleLoginClick}
              onPlanEventClick={() => handlePlanEventClick()}
              onHomeClick={handleHomeClick}
              onSolutionsClick={handleSolutionsClick}
              onEcoTipsClick={handleEcoTipsClick}
              onAboutClick={handleAboutClick}
              onConsultClick={handleConsultClick}
              onVendorsClick={handleVendorsClick}
            />
            <HomePage
              onPlanEventClick={() => handlePlanEventClick()}
              onLearnClick={handleEcoTipsClick}
              onCalculatorClick={handleCalculatorClick}
              onConsultClick={handleConsultClick}
            />
            <Footer />
          </div>
        )
    }
  }

  return <div className="min-h-screen">{renderCurrentView()}</div>
}
